function print_states_ysets(GSJ, y_att_sets, y_opr_sets, subset_idx, title_str)
% print_states_ysets
% 打印 Stealthy Joint Observer 各状态对应的 y-sets (attacker, operator)
% 当 GSJ 为空、jointMap 缺失、或集合尺寸不一致时，自动跳过而不报错。
%
% 使用格式：
%   print_states_ysets(GSJ, y_att_sets, y_opr_sets, [], 'GSJ1_B states with y-sets');

if nargin < 4 || isempty(subset_idx), subset_idx = []; end
if nargin < 5, title_str = 'States with y-sets'; end

fprintf('\n===== %s =====\n', title_str);

%% --- 情况1：GSJ 本身为空或结构异常 ---
if isempty(GSJ) || numel(GSJ) < 6 || ~iscell(GSJ)
    fprintf('(empty GSJ)\n');
    return;
end

n = 0;
try
    n = double(GSJ{1});
catch
    fprintf('(invalid GSJ structure)\n');
    return;
end

if n == 0
    fprintf('(∅)\n');   % 输出空集符号
    return;
end

%% --- 情况2：jointMap 缺失 ---
meta = GSJ{6};
if ~isstruct(meta) || ~isfield(meta, 'jointMap') || isempty(meta.jointMap)
    fprintf('(jointMap missing) -> (∅)\n');
    return;
end
jointMap = meta.jointMap;

%% --- 情况3：索引范围处理 ---
if isempty(subset_idx)
    subset_idx = 0:n-1;
else
    subset_idx = subset_idx(subset_idx < n);  % 防越界
end

%% --- 安全访问 y-sets ---
for s = subset_idx
    qa = jointMap(s+1,1);
    qo = jointMap(s+1,2);

    Ya = {}; Yo = {};
    if qa+1 <= numel(y_att_sets)
        Ya = y_att_sets{qa+1};
    end
    if qo+1 <= numel(y_opr_sets)
        Yo = y_opr_sets{qo+1};
    end

    % 转为字符串（兼容 cell / numeric）
    if isnumeric(Ya), Ya_str = num2str(Ya);
    elseif iscell(Ya), Ya_str = strjoin(string(Ya), ' ');
    else, Ya_str = string(Ya); end

    if isnumeric(Yo), Yo_str = num2str(Yo);
    elseif iscell(Yo), Yo_str = strjoin(string(Yo), ' ');
    else, Yo_str = string(Yo); end

    fprintf('(%2d) ({%s} , {%s})\n', s, Ya_str, Yo_str);
end
end
