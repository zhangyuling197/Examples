clear; clc;

% === 随机生成若干 NFA ===
Gn_list = generate_random_nfa_p(5, [15 20], [3 6], 0.4, 0.4, 0.4, '');%seed=42
% Gn_list = generate_random_nfa_p(5, [20 25], [3 6], 0.4, 0.4, 0.4, '');%seed=42
%Gn_list = generate_random_nfa_p(10, [15 30], [3 6], 0.4, 0.4, 0.4, '');%seed=345

% === 参数设置 ===
opts = struct('max_cycle_len', 12, 'verbose', false);

N = numel(Gn_list);
out_cell = cell(1, N);
err_cell = cell(1, N);

% === 串行运行 ===
for i = 1:N
    fprintf('\nProcessing sample %d/%d ...\n', i, N);
    try
        [out_cell{i}, err_cell{i}] = run_batch_pipeline_fixed(Gn_list{i}, opts);
    catch ME
        out_cell{i} = [];
        err_cell{i} = sprintf('Error: %s', ME.message);
    end
end

% === 打印汇总 ===
fprintf('\n===== PER-SAMPLE SUMMARY =====\n');
for i = 1:N
    fprintf('\n--- Sample %d ---\n', i);

    if ~isempty(err_cell{i})
        fprintf('ERROR: %s\n', err_cell{i});
        continue;
    end

    r = out_cell{i};

    % 打印 NFA / observer 统计
    try
        fprintf('NFA: n=%d, |T|=%d | Gd=%d, GJ=%d, GSJ=%d\n', ...
            r.nfa_n, r.nfa_T, r.gd_n, r.gj_n, r.gsj_n);
    catch
        fprintf('NFA/result fields missing for sample %d.\n', i);
    end

    % 打印时间消耗
    try
        fprintf('Times (s): A=%.6f, B=%.6f, C=%.6f, D=%.6f, TOTAL=%.6f\n', ...
            r.tA, r.tB, r.tC, r.tD, r.total);
    catch
    end

    % 打印攻击者存在性
    try
        fprintf('exists_attack=%d\n', r.exists_attack);
    catch
    end

    % 早停信息
    if isfield(r,'early_note') && ~isempty(r.early_note)
        fprintf('%s\n', r.early_note);
    end
end
