function pb_cycles = build_pb_cycles(GSJ1, SJ_jointMap, opr_card, varargin)
% BUILD_PB_CYCLES  生成潜在问题环集合 pb_cycles（cell 数组，元素为 0-based 的环序列）
% 条件：存在结点 q 使 |q_opr|>1（即 operator 估计的基数 > 1） → 该环“潜在有问题”
% 若有 list_cycles_johnson，优先用 simple cycles；否则退回 SCC 近似。

% 可选：'Mode','cycles' 或 'scc'   （默认 'cycles'，若 cycles 不可用则自动回退）
mode = 'cycles';
if ~isempty(varargin)
    for k = 1:2:numel(varargin)
        if strcmpi(varargin{k}, 'Mode'), mode = lower(varargin{k+1}); end
    end
end

n1  = double(GSJ1{1});
Ed1 = GSJ1{2};
T1  = double(GSJ1{3});      % [src sym dst] 0-based
if ischar(Ed1), Ed1 = arrayfun(@(c){char(c)}, Ed1); end

% 尝试 cycles
pb_cycles = {};
use_cycles = strcmp(mode,'cycles');
if use_cycles
    have_cycles = exist('list_cycles_johnson','file') == 2 || exist('list_cycles_johnson','file') == 3;
    if have_cycles
        cycles = list_cycles_johnson(n1, T1);   % cell: 每个元素是 0-based 的简单环序列 [q1 ... qh]
        for c = 1:numel(cycles)
            cyc = cycles{c};
            if isempty(cyc), continue; end
            % 条件：∃ 节点 |q_opr|>1
            if any(arrayfun(@(q) (opr_card(SJ_jointMap(q+1,2)+1) > 1), cyc))
                pb_cycles{end+1} = cyc(:)'; %#ok<AGROW>
            end
        end
        return;
    else
        % 没有 cycles 函数，转用 SCC
        mode = 'scc';
    end
end

% ---- SCC 近似：把每个“包含环”的 SCC（|SCC|>1 或 有自环）当作一个环（顺序用发现顺序）----
if strcmp(mode,'scc')
    SCCs = scc_kosaraju(n1, T1);  % 返回每个分量的 0-based 结点向量
    % 建邻接查表，便于检测自环
    hasSelfLoop = false(1,n1);
    for r = 1:size(T1,1)
        hasSelfLoop(T1(r,1)+1) = hasSelfLoop(T1(r,1)+1) || (T1(r,1)==T1(r,3));
    end
    for c = 1:numel(SCCs)
        nodes = SCCs{c}(:)';  % 0-based
        if isempty(nodes), continue; end
        isCycleLike = (numel(nodes) > 1) || hasSelfLoop(nodes(1)+1);
        if ~isCycleLike, continue; end
        % 条件：∃ 节点 |q_opr|>1
        if any(arrayfun(@(q) (opr_card(SJ_jointMap(q+1,2)+1) > 1), nodes))
            % 作为一个“环”近似返回（注意：不是严格的环序，但对“存在节点满足条件”的判定足够）
            pb_cycles{end+1} = nodes;
        end
    end
end
end

% ====== 依赖：Kosaraju SCC ======
function SCCs = scc_kosaraju(n, T)
    adj = cell(n,1); radj = cell(n,1);
    for i = 1:n, adj{i} = []; radj{i} = []; end
    for r = 1:size(T,1)
        s = T(r,1); t = T(r,3);
        adj{s+1}(end+1)  = t; 
        radj{t+1}(end+1) = s; 
    end
    vis = false(1,n); order = zeros(1,n); top = 0;
    for v = 0:n-1
        if ~vis(v+1), dfs1(v); end
    end
    vis(:) = false;
    SCCs = {};
    for k = n:-1:1
        v = order(k);
        if ~vis(v+1)
            comp = []; dfs2(v);
            SCCs{end+1} = comp; 
        end
    end
    function dfs1(v)
        vis(v+1) = true;
        for to = adj{v+1}
            if ~vis(to+1), dfs1(to); end
        end
        top = top + 1; order(top) = v;
    end
    function dfs2(v)
        vis(v+1) = true; comp(end+1) = v; 
        for to = radj{v+1}
            if ~vis(to+1), dfs2(to); end
        end
    end
end
