% NFA for the figure 1(a)
n = 6;
E = {'a','b','c'};   % a=1, b=2, c=3 ; epsilon=0

% T rows: [from_state, event_index, to_state]
T = [
    % from state 0 (-> 1)
    1, 3, 1;   % 0 --c--> 0 (self-loop)
    1, 1, 2;   % 0 --a--> 1
    1, 1, 5;   % 0 --a--> 4
    1, 2, 6;   % 0 --b--> 5

    % from state 1 -> epsilon -> 2
    2, 0, 3;   % 1 --ε--> 2

    % chain 2 -c-> 3 -c-> 3
    3, 3, 4;   % 2 --c--> 3
    4, 3, 4;   % 3 --c--> 3 (self-loop)

    % self-loops on c at states 4 and 5
    5, 3, 5;   % 4 --c--> 4
    6, 3, 6;   % 5 --c--> 5
];

X0 = [1];   % initial state is 0 in the figure
Xm = [];    % no marked states shown
Gn = {n, E, T, X0, Xm};

Sigma_o   = {'a','b','c'};
Sigma_ins = {'a'};
Sigma_era = {'b'};

clear opts;
opts = struct();
opts.verbose = true;
opts.max_cycle_len = 30;
opts.in_seq = {'a','b','c','a','b','c'};   % 可选：若省略，函数会使用内置默认序列
out = run_attack_demo(Gn, Sigma_o, Sigma_ins, Sigma_era, opts);


