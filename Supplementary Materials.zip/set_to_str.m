function s = set_to_str(S)
% 把一个数值向量（如 [1 3 5]）打印成 "{1 3 5}"；空集打印成 "{}"
    if isempty(S)
        s = '{}';
        return;
    end
    % 确保是行向量，元素为整数风格打印
    S = S(:).';
    if all(mod(S,1)==0)
        s = sprintf('%d ', S);
    else
        s = sprintf('%g ', S);
    end
    s = ['{', strtrim(s), '}'];
end
