function print_trimmed_SJ_as_y(GSJ1, y, sink_opr)
% GSJ1 : {n, Ed, T, init, [], meta}，其中 meta.jointMap 为 n×2，存 (q_att,q_opr) 0-based
% y    : NFA2DFA(Gn) 返回的 cell，y{k} 是原 NFA 状态集合（1-based下标）
% sink_opr : 操作者的 dump 状态（0-based）。该状态打印为空集 ∅

n = GSJ1{1};
if numel(GSJ1) < 6 || ~isstruct(GSJ1{6}) || ~isfield(GSJ1{6},'jointMap')
    error('GSJ1{6}.jointMap 不存在；请在构造时带上 meta.jointMap。');
end
jm = GSJ1{6}.jointMap;  % n×2, 0-based

fprintf('Trimmed SJ states mapped to y-sets:\n');
for s = 0:n-1
    qa = jm(s+1,1);    % q_att (0-based)
    qo = jm(s+1,2);    % q_opr (0-based)

    setA = y{qa+1};    % 攻击者这边的 y-集合
    if qo == sink_opr
        setO = [];     % 操作者在 sink：空集
    else
        setO = y{qo+1};
    end

    % 组装为花括号形式
    strA = sprintf('{%s}', strjoin(arrayfun(@num2str, setA, 'UniformOutput', false), ','));
    if isempty(setO)
        strO = '{ }';  % ∅
    else
        strO = sprintf('{%s}', strjoin(arrayfun(@num2str, setO, 'UniformOutput', false), ','));
    end

    fprintf('  state %-2d : ( %s , %s )\n', s, strA, strO);
end
end
