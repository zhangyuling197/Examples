function GSJ = build_stealthy_joint_observer(GJ, jointMap, sink_opr, Sigma_o, Sigma_ins, Sigma_era)
% BUILD_STEALTHY_JOINT_OBSERVER
%   Q_J^e = { (q_att, q_opr) | q_opr = d_emptyset }  (i.e., operator sink)
%   Fixed-point rule with:
%     (∃ e∈Σ_o) [ δ(q,e)∈Qwe ⇒ ( e∉Σ_era ∨ δ(q,e_-)∈Qwe ) ]
%     ∧ (∀ e_+∈Σ_+) [ δ(q,e_+)∈Qwe ]
%
% Inputs:
%   GJ        : joint observer (cell {n,Ed,T,init,...} or struct .n,.alphabet,.T,.init)
%               Td rows are [src sym dst], all 0-based
%   jointMap  : (#states x 2) double; row k -> (q_att, q_opr) for joint state (k-1)
%   sink_opr  : operator dump state index (0-based), i.e., d_emptyset
%   Sigma_o   : cellstr of observable base symbols (no suffix), e.g., {'a','b','c'}
%   Sigma_ins : cellstr of insertable base symbols (no suffix), e.g., {'a'}
%   Sigma_era : cellstr of erasable base symbols (no suffix), e.g., {'b'}
%
% Output:
%   GSJ       : cell {n_new, Ed, T_new, init_new, []} — trimmed stealthy joint observer
%
% Notes:
% - Alphabet Ed may include suffixed symbols 'e_+' and 'e_-'.
% - We remove weakly-exposing states and return the accessible part from init.

% ---------- Unpack GJ ----------
if iscell(GJ)
    n   = double(GJ{1});
    Ed  = GJ{2};
    Td  = double(GJ{3});
    init = []; if numel(GJ)>=4, init = GJ{4}; end
else
    n   = double(GJ.n);
    Ed  = GJ.alphabet;
    Td  = double(GJ.T);
    init = []; if isfield(GJ,'init'), init = GJ.init; end
end
if isempty(init), init = 0; end  % default initial joint state is 0-based 0

% Normalize Ed to cellstr
if ischar(Ed), Ed = arrayfun(@(c){char(c)}, Ed); end

% ---------- Build symbol -> index (0-based) ----------
sym2idx = containers.Map();
for k = 1:numel(Ed)
    sym2idx(Ed{k}) = int32(k-1);
end

% ---------- Per-state delta: delta{q+1}(symIdx) -> dst (0-based) ----------
delta = cell(n,1);
for r = 1:size(Td,1)
    s = Td(r,1); a = Td(r,2); t = Td(r,3);
    if isempty(delta{s+1})
        delta{s+1} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta{s+1}(int32(a)) = int32(t);
end

% ---------- Build Σ_o indices (from base names, no suffix) ----------
So_idx = [];
if ~isempty(Sigma_o)
    for k = 1:numel(Sigma_o)
        name = Sigma_o{k};
        if isKey(sym2idx, name)
            So_idx(end+1) = double(sym2idx(name)); %#ok<AGROW>
        end
    end
end

% ---------- Build Σ_+ indices (from base names + '_+') ----------
Splus_idx = [];
if ~isempty(Sigma_ins)
    for k = 1:numel(Sigma_ins)
        namep = [Sigma_ins{k}, '_+'];
        if isKey(sym2idx, namep)
            Splus_idx(end+1) = double(sym2idx(namep)); %#ok<AGROW>
        end
    end
end

% ---------- Build e -> e_- mapping (index or -1) ----------
minusIdx = containers.Map();
if ~isempty(Sigma_o)
    for k = 1:numel(Sigma_o)
        e = Sigma_o{k};
        name_minus = [e, '_-'];
        if isKey(sym2idx, name_minus)
            minusIdx(e) = double(sym2idx(name_minus));
        else
            minusIdx(e) = -1;
        end
    end
end

% ---------- Erasable membership map ----------
isEra = containers.Map();
if ~isempty(Sigma_o)
    for k = 1:numel(Sigma_o)
        e = Sigma_o{k};
        isEra(e) = ismember(e, Sigma_era);
    end
end

% ---------- Exposing states: q_opr == sink_opr ----------
Qe = false(1,n);
for q = 0:n-1
    if jointMap(q+1,2) == sink_opr
        Qe(q+1) = true;
    end
end

% ---------- Fixed-point: Qwe ----------
Qwe = Qe;  % start from exposing
changed = true;
while changed
    Qwe_new = Qwe;

    for q = 0:n-1
        if Qwe(q+1), continue; end  % already weakly exposing

        % (1)  ∃ e∈Σ_o:  δ(q,e)∈Qwe  ∧  ( e∉Σ_era  ∨  δ(q,e_-)∈Qwe )
ok1 = false;
for id = So_idx
    % 必须先有 δ(q,e) 且目标在 Qwe
    if ~isempty(delta{q+1}) && isKey(delta{q+1}, int32(id))
        dst = double(delta{q+1}(int32(id)));
        if Qwe(dst+1)
            e_name = Ed{id+1};  % 基符号名
            erasable = false;
            if isKey(isEra, e_name)
                erasable = isEra(e_name);
            end
            if ~erasable
                ok1 = true; break;   % e 不可擦，满足
            else
                % e 可擦，则还需 δ(q,e_-) ∈ Qwe
                idm = -1;
                if isKey(minusIdx, e_name)
                    idm = minusIdx(e_name);
                end
                if idm >= 0 && isKey(delta{q+1}, int32(idm))
                    dstm = double(delta{q+1}(int32(idm)));
                    if Qwe(dstm+1)
                        ok1 = true; break;
                    end
                end
            end
        end
    end
end
if ~ok1, continue; end


        % (2) ∀ e_+∈Σ_+: δ(q,e_+) ∈ Qwe
        ok2 = true;
        for idp = Splus_idx
            if isempty(delta{q+1}) || ~isKey(delta{q+1}, int32(idp))
                ok2 = false; break;
            else
                dstp = double(delta{q+1}(int32(idp)));
                if ~Qwe(dstp+1)
                    ok2 = false; break;
                end
            end
        end

        if ok1 && ok2
            Qwe_new(q+1) = true;
        end
    end

    changed = ~isequal(Qwe_new, Qwe);
    Qwe = Qwe_new;
end

% ---------- Remove weakly exposing and take accessible part from init ----------
keep = ~Qwe;  % keep stealthy states
if ~keep(init+1)
    GSJ = {0, Ed, zeros(0,3), [], []};  % empty
    return;
end

% filter edges to kept states
rows = [];
for r = 1:size(Td,1)
    s = Td(r,1); a = Td(r,2); t = Td(r,3);
    if keep(s+1) && keep(t+1)
        rows(end+1,:) = [s,a,t]; %#ok<AGROW>
    end
end

% BFS reachable from init on restricted graph
adj = containers.Map('KeyType','int32','ValueType','any');
for r = 1:size(rows,1)
    s = rows(r,1); t = rows(r,3);
    if ~isKey(adj, int32(s)), adj(int32(s)) = int32([]); end
    adj(int32(s)) = [adj(int32(s)), int32(t)];
end
vis = false(1,n); vis(init+1) = true;
Q = int32(init);
while ~isempty(Q)
    cur = Q(1); Q(1) = [];
    if isKey(adj, cur)
        nxts = adj(cur);
        for dd = nxts
            if ~vis(double(dd)+1)
                vis(double(dd)+1) = true;
                Q(end+1) = dd; %#ok<AGROW>
            end
        end
    end
end

% keep only visited & kept
rows2 = [];
for r = 1:size(rows,1)
    s = rows(r,1); t = rows(r,3);
    if vis(s+1) && vis(t+1)
        rows2(end+1,:) = rows(r,:); %#ok<AGROW>
    end
end
states_keep = find(vis & keep) - 1;  % 0-based list

% ---------- 压缩并打包 ----------
% compress indices to 0..n_new-1
old2new = -ones(1,n);
for k = 1:numel(states_keep)
    old2new(states_keep(k)+1) = k-1;
end

Td_new = zeros(size(rows2,1),3);
for r = 1:size(rows2,1)
    s = rows2(r,1); a = rows2(r,2); t = rows2(r,3);
    Td_new(r,:) = [old2new(s+1), a, old2new(t+1)];
end

init_new = old2new(init+1);
n_new    = numel(states_keep);

% ---------- 新→旧映射（0-based） ----------
% states_keep(k) 恰好就是新状态 k-1 对应的旧状态索引
if n_new > 0
    new2old = states_keep(:)';     % 1×n_new 行向量，0-based
else
    new2old = [];
end

% ---------- 打包 meta ----------
meta.new2old = new2old;            % 0-based: new -> old
if ~isempty(new2old) && exist('jointMap','var') && ~isempty(jointMap)
    % jointMap 是函数的输入参数：旧的 (q_att,q_opr) 表（|Q_J|×2，0-based）
    meta.jointMap = jointMap(new2old+1, :);   % n_new×2
else
    meta.jointMap = [];
end

% ---------- 返回 ----------
GSJ = {n_new, Ed, Td_new, init_new, [], meta};
end