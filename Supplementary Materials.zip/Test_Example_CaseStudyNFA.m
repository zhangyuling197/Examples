n  = 9;
E  = {'a','b','c','d'};     % observable alphabet
% T rows: [src, symIdx, dst]  (symIdx: 1=a, 2=b, 3=c, 4=d; 0 = epsilon)
T = [
    1, 1, 2;   % 1 --a--> 2
    1, 1, 4;   % 1 --a--> 4
    1, 0, 5;   % 1 --ε--> 5
    2, 2, 3;   % 2 --b--> 3
    3, 4, 6;   % 3 --d--> 6
    4, 2, 7;   % 4 --b--> 7
    5, 1, 4;   % 5 --a--> 4
    7, 4, 8;   % 7 --d--> 8
    7, 3, 5;   % 7 --c--> 5
    8, 3, 9;   % 8 --c--> 9
    9, 1, 6;   % 9 --a--> 6
    6, 3, 2;   % 6 --c--> 2
    6, 0, 8;   % 6 --ε--> 8
];

X0 = [1];     % initial state = 1
Xm = [];      % (no marked states needed for observer construction)

Gn = {n, E, T, X0, Xm};

Sigma_o={'a','b','c','d'};
Sigma_ins = {'b','d'};
Sigma_era = {'b','d'};

clear opts;
opts = struct();
opts.verbose = true;


opts.max_cycle_len = 30;
opts.in_seq = {'a','b','c','a','b','c'};   % 可选：若省略，函数会使用内置默认序列
out = run_attack_demo(Gn, Sigma_o, Sigma_ins, Sigma_era, opts);