clear; clc;
%% NFA for the figure 1(a)
n = 6;
E = {'a','b','c'};   % a=1, b=2, c=3 ; epsilon=0

% T rows: [from_state, event_index, to_state]
T = [
    % from state 0 (-> 1)
    1, 3, 1;   % 0 --c--> 0 (self-loop)
    1, 1, 2;   % 0 --a--> 1
    1, 1, 5;   % 0 --a--> 4
    1, 2, 6;   % 0 --b--> 5

    % from state 1 -> epsilon -> 2
    2, 0, 3;   % 1 --ε--> 2

    % chain 2 -c-> 3 -c-> 3
    3, 3, 4;   % 2 --c--> 3
    4, 3, 4;   % 3 --c--> 3 (self-loop)

    % self-loops on c at states 4 and 5
    5, 3, 5;   % 4 --c--> 4
    6, 3, 6;   % 5 --c--> 5
];

X0 = [1];   % initial state is 0 in the figure
Xm = [];    % no marked states shown
Gn = {n, E, T, X0, Xm};

Sigma_o   = {'a','b','c'};
Sigma_ins = {'a'};
Sigma_era = {'a','b'};
%% NFA for the figure 1(a)
% n = 6;
% E = {'a','b','c'};   % a=1, b=2, c=3 ; epsilon=0
% 
% % T rows: [from_state, event_index, to_state]
% T = [
%     % from state 0 (-> 1)
%     1, 3, 1;   % 0 --c--> 0 (self-loop)
%     1, 1, 2;   % 0 --a--> 1
%     1, 1, 5;   % 0 --a--> 4
%     1, 2, 6;   % 0 --b--> 5
% 
%     % from state 1 -> epsilon -> 2
%     2, 0, 3;   % 1 --ε--> 2
% 
%     % chain 2 -c-> 3 -c-> 3
%     3, 3, 4;   % 2 --c--> 3
%     4, 3, 4;   % 3 --c--> 3 (self-loop)
% 
%     % self-loops on c at states 4 and 5
%     5, 3, 5;   % 4 --c--> 4
%     6, 3, 6;   % 5 --c--> 5
% ];
% 
% X0 = [1];   % initial state is 0 in the figure
% Xm = [];    % no marked states shown
% Gn = {n, E, T, X0, Xm};
% 
% Sigma_o   = {'a','b','c'};
% Sigma_ins = {'a'};
% Sigma_era = {'b'};
%% NFA for the figure 8
% n = 6;
% E = {'a','b','c','d','e'};   % a=1, b=2, c=3, d=4, e=5;  epsilon=0
% 
% % T rows are [from_state, event_index, to_state]
% T = [
%     % state 0 (-> 1)
%     1, 3, 1;   % 0 --c--> 0
%     1, 0, 2;   % 0 --ε--> 1
%     1, 1, 4;   % 0 --a--> 3
%     1, 4, 6;   % 0 --d--> 5
%     1, 2, 5;   % 0 --b--> 4
%     1, 5, 5;   % 0 --e--> 4
% 
%     % state 1 (-> 2)
%     2, 1, 3;   % 1 --a--> 2
% 
%     % state 2 (self-loop on c)
%     3, 3, 3;   % 2 --c--> 2
% 
%     % state 3 (self-loop on c)
%     4, 3, 4;   % 3 --c--> 3
% 
%     % state 5 (-> 4, self-loop on c)
%     6, 2, 5;   % 5 --b--> 4
%     6, 3, 6;   % 5 --c--> 5
% 
%     % state 4 (self-loop on c)
%     5, 3, 5;   % 4 --c--> 4
% ];
% 
% X0 = [1];     % initial state is node 0 in the figure
% Xm = [];      % (no marked states in the figure)
% Gn = {n, E, T, X0, Xm};
% 
% % (可按需要设置观测/可插入/可擦除事件)
% Sigma_o   = {'a','b','c','d','e'};  % 全部可观测（如需与论文设定一致可改）
% Sigma_ins = {};                      % 可插入事件（按需）
% Sigma_era = {'d','e'};                      % 可擦除事件（按需）

%% 1) NFA -> observer  
tstart = tic();
[Gd, y] = NFA2DFA(Gn);
Gd = normalize_Td_symbols_zero_based(Gd); % 索引从0开始
t_obs = toc(tstart);   % 观测器计算时间
fprintf('Time: NFA -> observer: %.6f s\n', t_obs);

%% 2) 从 observer 完成 到 完成 Stealthy JO（measure this span）
tstart = tic();

% 2a) 构建 G_att / G_opr
G_att   = build_attacker_observer(Gd, Sigma_ins, Sigma_era);
G_opr   = build_operator_observer(Gd, Sigma_ins, Sigma_era);
G_att{4} = 0;
G_opr{4} = 0;

% 2b) 合成 joint observer
GJ = build_joint_observer(G_att, G_opr);

% 2c) 检测 dump state
sink_opr = detect_operator_sink(G_opr);

% 2d) 基于 y 计算 |q_opr|
nd_base  = Gd{1};
nd_opr   = G_opr{1};
opr_card = zeros(1, nd_opr);
for j = 0:nd_base-1
    opr_card(j+1) = numel(y{j+1});%operator的|状态估计|
end
opr_card(sink_opr+1) = 0;% 无效状态

% 2e) 构造 Stealthy JO，并拿到 SJ_jointMap
GSJ = build_stealthy_joint_observer(GJ, GJ.jointMap, sink_opr, Sigma_o, Sigma_ins, Sigma_era);
meta = GSJ{6};              % new2old
SJ_jointMap = GJ.jointMap(meta.new2old+1, :);

t_obs_to_SJ = toc(tstart);   % 从观测器到得到 GSJ 的时间
fprintf('Time: observer -> Stealthy JO (GSJ) ready: %.6f s\n', t_obs_to_SJ);

% 输出一些统计信息（可选）
if iscell(GJ)
    n_J  = GJ{1}; T_J  = GJ{3}; Ed_J = GJ{2};
else
    n_J  = GJ.n;   T_J  = GJ.T; Ed_J = GJ.alphabet;
end
fprintf('\n===== Joint Observer (G_J) Statistics =====\n');
fprintf('G_J states count       : %d\n', n_J);
fprintf('G_J transitions count  : %d\n', size(T_J, 1));
fprintf('\n===== Stealthy Joint Observer (SJ) Statistics =====\n');
n_SJ = GSJ{1}; T_SJ = GSJ{3};
fprintf('SJ states count       : %d\n', n_SJ);
fprintf('SJ transitions count  : %d\n', size(T_SJ, 1));

%% 3) 以 GSJ 为起点做后续修剪/准备并调用 check_successful_attacker（测量此段时间）
tstart = tic();

% 3a) Trimmed--分两类
[GSJ1_A, GSJ1_B] = build_trimmed_stealthy_joint_observer(GSJ, Sigma_o, Sigma_ins, Sigma_era, SJ_jointMap, opr_card);

% 3b) 构造 y_att_sets / y_opr_sets（便于后续打印/分析）
nd_base = Gd{1};
y_att_sets = y;
n_opr = G_opr{1};
y_opr_sets = cell(1, n_opr);
for j = 1:nd_base
    y_opr_sets{j} = y{j};
end
for j = nd_base+1:n_opr
    y_opr_sets{j} = [];
end

% 3c) 为 GSJ1_A/B 填 jointMap（若需要）
if exist('GJ','var') && isfield(GJ,'jointMap')
    SJ_jointMap = GJ.jointMap(GSJ{6}.new2old+1, :);
elseif exist('SJ_jointMap','var')
    % already present
else
    error('Need either GJ.jointMap or SJ_jointMap to rebuild jointMap.');
end
if numel(GSJ1_A) >= 6 && isfield(GSJ1_A{6},'new2old')
    GSJ1_A{6}.jointMap = SJ_jointMap(GSJ1_A{6}.new2old+1, :);
end
if numel(GSJ1_B) >= 6 && isfield(GSJ1_B{6},'new2old')
    GSJ1_B{6}.jointMap = SJ_jointMap(GSJ1_B{6}.new2old+1, :);
end

% 3d) 准备并调用 check_successful_attacker
obs_state_card = cellfun(@numel, y);        % y 为 observer 的集合映射
opts.max_cycle_len = 20;
opts.verbose = true;

res = check_successful_attacker(Gd, GSJ1_A, GSJ1_B, opr_card, obs_state_card, opts);
%disp(res);   % 若你不想打印最终结构体，保持注释

t_SJ_to_check = toc(tstart);   % 从 GSJ 可用到 check 返回所花时间
%fprintf('Time: GSJ ready -> check_successful_attacker returned: %.6f s\n', t_SJ_to_check);

%% 4) 汇总三段时间并保存
% timings.t_obs = t_obs;
% timings.t_obs_to_SJ = t_obs_to_SJ;
% timings.t_SJ_to_check = t_SJ_to_check;
% timings.total = t_obs + t_obs_to_SJ + t_SJ_to_check;
% 
% fprintf('\n===== TIMINGS SUMMARY =====\n');
% fprintf('1) NFA -> observer:                          %.6f s\n', timings.t_obs);
% fprintf('2) observer -> GSJ ready:                    %.6f s\n', timings.t_obs_to_SJ);
% fprintf('3) GSJ ready -> check returned:              %.6f s\n', timings.t_SJ_to_check);
% fprintf('Total (1+2+3):                               %.6f s\n', timings.total);

% optionally return/save timings: save('timings.mat','timings','res');
