function varargout = build_trimmed_stealthy_joint_observer( ...
    GSJ, Sigma_o, Sigma_ins, Sigma_era, SJ_jointMap, opr_card)
% BUILD_TRIMMED_STEALTHY_JOINT_OBSERVER
% Two branches:
%   A) SCC contains a node with |q_opr|>1
%   B) There exists an SCC that forms a cycle and ALL nodes in it have |q_opr|==1
% No nested functions are used (compat-friendly).
%
% Outputs (flexible):
%   A_only                     -> returns GSJ1_A
%   [A,B]                      -> returns GSJ1_A, GSJ1_B
%   [A,B,store]                -> plus artifacts
%
% It also prints both A/B results (state/transition counts and full edges).

% ---------- Unpack ----------
nS   = double(GSJ{1});
Ed   = GSJ{2};
Td   = double(GSJ{3});  % [src, sym, dst]  (0-based)
init = []; if numel(GSJ)>=4, init = GSJ{4}; end
if isempty(init), init = 0; end
if ischar(Ed), Ed = arrayfun(@(c){char(c)}, Ed); end

% ---------- Build symbol maps ----------
sym2idx = containers.Map();
for k = 1:numel(Ed), sym2idx(Ed{k}) = int32(k-1); end

% indices of Σ_o, Σ_+, Σ_- (0-based)
So_idx     = base_set_to_indices(Sigma_o,   sym2idx, '');
Splus_idx  = base_set_to_indices(Sigma_ins, sym2idx, '_+');
Sminus_idx = base_set_to_indices(Sigma_era, sym2idx, '_-');

% mapping e -> e_- index (or -1)
minusIdx = containers.Map();
for k = 1:numel(Sigma_o)
    e = Sigma_o{k};
    name_minus = [e, '_-'];
    if isKey(sym2idx, name_minus)
        minusIdx(e) = double(sym2idx(name_minus));
    else
        minusIdx(e) = -1;
    end
end

% erasable map
isEra = containers.Map();
for k = 1:numel(Sigma_o)
    isEra(Sigma_o{k}) = ismember(Sigma_o{k}, Sigma_era);
end

% per-state delta (0-based symbol -> 0-based dst)
delta = cell(nS,1);
hasSelfLoop = false(1, nS);
for r = 1:size(Td,1)
    s = Td(r,1); a = Td(r,2); t = Td(r,3);
    if isempty(delta{s+1})
        delta{s+1} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta{s+1}(int32(a)) = int32(t);
    if s == t, hasSelfLoop(s+1) = true; end
end

% ---------- SCC decomposition ----------
SCCs = scc_kosaraju(nS, Td);

% ========== Condition A: SCC (∃ node with |q_opr|>1) ==========
C_pb_A = false(numel(SCCs), 1);
Q_pb_A = false(1, nS);
for c = 1:numel(SCCs)
    nodes = SCCs{c};
    bad = false;
    for q = nodes(:)'
        q_opr = SJ_jointMap(q+1, 2);
        if opr_card(q_opr+1) > 1
            bad = true; break;
        end
    end
    if bad
        C_pb_A(c) = true;
        Q_pb_A(nodes+1) = true;
    end
end
[Qb_A, C_b_A] = remove_plus_escapable_sets(Q_pb_A, C_pb_A, SCCs, Td, Splus_idx, nS);

% ========== Condition B: SCC is a cycle AND ALL nodes have |q_opr|==1 ==========
C_pb_B = false(numel(SCCs), 1);
Q_pb_B = false(1, nS);
for c = 1:numel(SCCs)
    nodes = SCCs{c};
    if numel(nodes) == 1 && ~hasSelfLoop(nodes(1)+1)
        % single node without self-loop -> not a cycle
        continue;
    end
    all_singleton = true;
    for q = nodes(:)'
        q_opr = SJ_jointMap(q+1, 2);
        if opr_card(q_opr+1) ~= 1
            all_singleton = false; break;
        end
    end
    if all_singleton
        C_pb_B(c) = true;
        Q_pb_B(nodes+1) = true;
    end
end
[Qb_B, C_b_B] = remove_plus_escapable_sets(Q_pb_B, C_pb_B, SCCs, Td, Splus_idx, nS); %#ok<NASGU>

% ========== Unified trimming pipeline ==========
GSJ1_A = trim_pipeline(Qb_A, GSJ, Ed, Td, init, ...
    So_idx, Sminus_idx, Splus_idx, minusIdx, isEra, delta, SJ_jointMap);

GSJ1_B = trim_pipeline(Qb_B, GSJ, Ed, Td, init, ...
    So_idx, Sminus_idx, Splus_idx, minusIdx, isEra, delta, SJ_jointMap);

% ========== Print summaries as requested ==========
% print_gsj_summary('GSJ1_A', GSJ1_A);
% print_gsj_summary('GSJ1_B', GSJ1_B);

% ========== Flexible returns ==========
store = struct();
store.A.SCCs  = SCCs; store.A.C_pb = C_pb_A; store.A.Q_pb = Q_pb_A; store.A.Qb = Qb_A;
store.B.SCCs  = SCCs; store.B.C_pb = C_pb_B; store.B.Q_pb = Q_pb_B; store.B.Qb = Qb_B;

switch nargout
    case 0
        varargout = {};
    case 1
        varargout = {GSJ1_A};
    case 2
        varargout = {GSJ1_A, GSJ1_B};
    otherwise
        varargout = {GSJ1_A, GSJ1_B, store};
end

end % ===== END OF MAIN =====


% ============================ helpers (NO nested functions) ============================

function GSJ1 = trim_pipeline(Qb, GSJ, Ed, Td, init, ...
    So_idx, Sminus_idx, Splus_idx, minusIdx, isEra, delta, SJ_jointMap)

nS = double(GSJ{1});
if ~any(Qb)
    meta = struct();
    meta.new2old = 0:nS-1;
    if exist('SJ_jointMap','var') && ~isempty(SJ_jointMap)
        meta.jointMap = SJ_jointMap;
    else
        meta.jointMap = [];
    end
    GSJ1 = {GSJ{1}, GSJ{2}, GSJ{3}, GSJ{4}, [], meta};
    return;
end

% weak-problem closure
Qwb = Qb;
changed = true;
while changed
    Qwb_new = Qwb;
    for q = 0:nS-1
        if Qwb(q+1), continue; end
        % (1)
        ok1 = false;
        for id = So_idx
            if ~isempty(delta{q+1}) && isKey(delta{q+1}, int32(id))
                dst = double(delta{q+1}(int32(id)));
                if Qwb(dst+1)
                    e_name = Ed{id+1};
                    erasable = false;
                    if isKey(isEra, e_name), erasable = isEra(e_name); end
                    if ~erasable
                        ok1 = true; break;
                    else
                        idm = -1;
                        if isKey(minusIdx, e_name), idm = minusIdx(e_name); end
                        if idm >= 0 && isKey(delta{q+1}, int32(idm))
                            dstm = double(delta{q+1}(int32(idm)));
                            if Qwb(dstm+1)
                                ok1 = true; break;
                            end
                        end
                    end
                end
            end
        end
        if ~ok1, continue; end
        % (2)
        ok2 = true;
        for idp = Splus_idx
            if isempty(delta{q+1}) || ~isKey(delta{q+1}, int32(idp))
                ok2 = false; break;
            else
                dstp = double(delta{q+1}(int32(idp)));
                if ~Qwb(dstp+1), ok2 = false; break; end
            end
        end
        if ok1 && ok2
            Qwb_new(q+1) = true;
        end
    end
    changed = ~isequal(Qwb_new, Qwb);
    Qwb = Qwb_new;
end

% remove nodes, keep reachable from init
keep = ~Qwb;
rows = Td( keep(Td(:,1)+1) & keep(Td(:,3)+1), : );
adj_all = build_adj(numel(keep), rows);
vis = reachable_from(init, adj_all, numel(keep));
rows2 = rows( vis(rows(:,1)+1) & vis(rows(:,3)+1), : );
states_keep = find(vis & keep) - 1;

% deadlock pruning
dead = false(size(keep));
for q = states_keep(:)'
    if ~any(rows2(:,1)==q)
        dead(q+1) = true;
    end
end
Ao_idx = union(So_idx, Sminus_idx);
pred = build_pred_by_symbols(numel(keep), rows2, Ao_idx);
changed = true;
while changed
    changed = false;
    for q = states_keep(:)'
        if dead(q+1), continue; end
        if isKey(pred, int32(q))
            P = pred(int32(q));
            if any(dead(double(P)+1))
                dead(q+1) = true; changed = true;
            end
        end
    end
end

keep2 = keep & ~dead;
rows3 = Td( keep2(Td(:,1)+1) & keep2(Td(:,3)+1), : );
adj_final = build_adj(numel(keep2), rows3);
vis2 = reachable_from(init, adj_final, numel(keep2));
rows4 = rows3( vis2(rows3(:,1)+1) & vis2(rows3(:,3)+1), : );
states_final = find(vis2 & keep2) - 1;

% reindex
old2new = -ones(1, numel(keep2));
for k = 1:numel(states_final)
    old2new(states_final(k)+1) = k-1;
end
Td_new = zeros(size(rows4,1), 3);
for r = 1:size(rows4,1)
    s = rows4(r,1); a = rows4(r,2); t = rows4(r,3);
    Td_new(r,:) = [ old2new(s+1), a, old2new(t+1) ];
end
init_new = old2new(init+1);
n_new    = numel(states_final);

meta.new2old = states_final(:)'; % 0-based
if exist('SJ_jointMap','var') && ~isempty(SJ_jointMap)
    meta.jointMap = SJ_jointMap(states_final+1, :);
else
    meta.jointMap = [];
end

Ed_out = GSJ{2};
GSJ1 = { n_new, Ed_out, Td_new, init_new, [], meta };
end

function [Qb_out, Cb_out] = remove_plus_escapable_sets(Q_pb, C_pb, groups, Td, Splus_idx, nS)
Qb_out = Q_pb;
Cb_out = C_pb;
if ~any(C_pb), return; end
T_plus = filter_transitions_by_symbols(Td, Splus_idx);
adjP   = build_adj(nS, T_plus);

changed = true;
while changed
    changed = false;
    for c = find(Cb_out(:))'
        nodes = groups{c};
        in_set = false(1,nS); in_set(nodes+1) = true;
        escapable = false;
        for s = nodes(:)'
            if can_escape_plus_only(s, in_set, adjP)
                escapable = true; break;
            end
        end
        if escapable
            Cb_out(c) = false;
            Qb_out(nodes+1) = false;
            changed = true;
        end
    end
end
end

function idxs = base_set_to_indices(baseSet, sym2idx, suffix)
    idxs = [];
    if isempty(baseSet), return; end
    for k = 1:numel(baseSet)
        name = [baseSet{k}, suffix];
        if isKey(sym2idx, name)
            idxs(end+1) = double(sym2idx(name)); %#ok<AGROW>
        end
    end
end

function Tsel = filter_transitions_by_symbols(T, symIdxList)
    if isempty(symIdxList)
        Tsel = zeros(0,3);
    else
        mask = false(size(T,1),1);
        for a = symIdxList(:)'
            mask = mask | (T(:,2)==a);
        end
        Tsel = T(mask,:);
    end
end

function adj = build_adj(n, T)
    adj = containers.Map('KeyType','int32','ValueType','any');
    for r = 1:size(T,1)
        s = T(r,1); t = T(r,3);
        if ~isKey(adj, int32(s)), adj(int32(s)) = int32([]); end
        adj(int32(s)) = [adj(int32(s)), int32(t)];
    end
end

function vis = reachable_from(s0, adj, n)
    vis = false(1,n); vis(s0+1) = true;
    Q = int32(s0);
    while ~isempty(Q)
        cur = Q(1); Q(1) = [];
        if isKey(adj, cur)
            nxt = adj(cur);
            for v = nxt
                dv = double(v);
                if ~vis(dv+1)
                    vis(dv+1) = true; Q(end+1) = v; %#ok<AGROW>
                end
            end
        end
    end
end

function yes = can_escape_plus_only(s, inS, adjP)
    vis = false(size(inS)); Q = int32(s);
    vis(s+1) = true; yes = false;
    while ~isempty(Q)
        cur = Q(1); Q(1) = [];
        if isKey(adjP, cur)
            nxt = adjP(cur);
            for v = nxt
                dv = double(v);
                if ~inS(dv+1)
                    yes = true; return;
                end
                if ~vis(dv+1)
                    vis(dv+1) = true; Q(end+1) = v; %#ok<AGROW>
                end
            end
        end
    end
end

function SCCs = scc_kosaraju(n, T)
    adj = cell(n,1); radj = cell(n,1);
    for i = 1:n, adj{i} = []; radj{i} = []; end
    for r = 1:size(T,1)
        s = T(r,1); t = T(r,3);
        adj{s+1}(end+1)  = t; %#ok<AGROW>
        radj{t+1}(end+1) = s; %#ok<AGROW>
    end
    vis = false(1,n); order = zeros(1,n); top = 0;
    for v = 0:n-1
        if ~vis(v+1), dfs1(v); end
    end
    vis(:) = false;
    SCCs = {};
    for k = n:-1:1
        v = order(k);
        if ~vis(v+1)
            comp = []; dfs2(v);
            SCCs{end+1} = comp; %#ok<AGROW>
        end
    end
    function dfs1(v)
        vis(v+1) = true;
        for to = adj{v+1}
            if ~vis(to+1), dfs1(to); end
        end
        top = top + 1; order(top) = v;
    end
    function dfs2(v)
        vis(v+1) = true; comp(end+1) = v; %#ok<AGROW>
        for to = radj{v+1}
            if ~vis(to+1), dfs2(to); end
        end
    end
end

function pred = build_pred_by_symbols(n, T, symIdxList)
    pred = containers.Map('KeyType','int32','ValueType','any');
    if isempty(T), return; end
    mask = false(size(T,1),1);
    for a = symIdxList(:)'
        mask = mask | (T(:,2)==a);
    end
    TT = T(mask,:);
    for r = 1:size(TT,1)
        s = TT(r,1); t = TT(r,3);
        if ~isKey(pred, int32(t)), pred(int32(t)) = int32([]); end
        pred(int32(t)) = [pred(int32(t)), int32(s)];
    end
end

function print_gsj_summary(tag, G)
% 打印 {n, Ed, Td, init} 概要与全部转移
    if isempty(G)
        fprintf('[%s] (empty)\n', tag);
        return;
    end
    n    = double(G{1});
    Ed   = G{2};
    Td   = double(G{3});
    init = double(G{4});

    fprintf('=== %s ===\n', tag);
    fprintf('States (n): %d\n', n);
    fprintf('Transitions (|T|): %d\n', size(Td,1));
    fprintf('Init: %d\n', init);

    if isempty(Td)
        fprintf('  (no transitions)\n');
        return;
    end
    for r = 1:size(Td,1)
        s  = Td(r,1);
        a  = Td(r,2);
        t  = Td(r,3);
        symName = '(?)';
        if a+1>=1 && a+1<=numel(Ed)
            try, symName = Ed{a+1}; catch, end
        end
        fprintf('  %d -- %s(%d) --> %d\n', s, symName, a, t);
    end
end
