function out = run_attack_demo(Gn, Sigma_o, Sigma_ins, Sigma_era, opts)

if nargin < 5
    opts = struct();
end

% If opts is not a scalar struct, reset to scalar struct
if ~isstruct(opts) || numel(opts) ~= 1
    opts = struct();
end

% default values for basic fields (use separate checks to avoid parsing issues)
if ~isfield(opts, 'max_cycle_len')
    opts.max_cycle_len = 20;
else
    if isempty(opts.max_cycle_len)
        opts.max_cycle_len = 20;
    end
end

if ~isfield(opts, 'verbose')
    opts.verbose = true;
else
    if isempty(opts.verbose)
        opts.verbose = true;
    end
end

% -------------------------------------------------------------------------
%% 0) Unpack Gn
n   = Gn{1};
E   = Gn{2};
T   = Gn{3};
X0  = Gn{4};
Xm  = Gn{5};

%% 1) NFA -> observer (DFA-like 'observer' mapping)
if opts.verbose, fprintf('1) Build base observer from NFA...\n'); end
[Gd, y] = NFA2DFA(Gn);
try
    Gd = normalize_Td_symbols_zero_based(Gd);
catch
    if opts.verbose
        warning('normalize_Td_symbols_zero_based failed or not available; continuing without normalization.');
    end
end

%% 2) Build attacker / operator observers
if opts.verbose, fprintf('2) Build attacker/operator observers...\n'); end
G_att = build_attacker_observer(Gd, Sigma_ins, Sigma_era);
G_opr = build_operator_observer(Gd, Sigma_ins, Sigma_era);
if iscell(G_att) && numel(G_att) >= 4, G_att{4} = 0; end
if iscell(G_opr) && numel(G_opr) >= 4, G_opr{4} = 0; end

%% 3) Joint observer
if opts.verbose, fprintf('3) Build joint observer (GJ)...\n'); end
GJ = build_joint_observer(G_att, G_opr);

if iscell(GJ)
    n_J = GJ{1}; T_J = GJ{3}; Ed_J = GJ{2};
else
    n_J = getfield_safe(GJ, 'n', NaN);
    T_J = getfield_safe(GJ, 'T', []);
    Ed_J = getfield_safe(GJ, 'alphabet', []);
end

fprintf('\n===== Joint Observer (G_J) Statistics =====\n');
fprintf('G_J states count       : %d\n', n_J);
fprintf('G_J transitions count  : %d\n', size(T_J, 1));

%% 4) detect operator sink (if any)
sink_opr = detect_operator_sink(G_opr);

%% 5) compute operator-cardinality per base-observer state (recommended)
nd_base = Gd{1};
nd_opr  = G_opr{1};
opr_card = zeros(1, nd_opr);
for j = 0:nd_base-1
    opr_card(j+1) = numel(y{j+1});
end
if ~isempty(sink_opr)
    opr_card(sink_opr+1) = 0;
end

%% 6) build stealthy joint observer (GSJ)
if opts.verbose, fprintf('6) Build stealthy joint observer (GSJ)...\n'); end
GSJ = build_stealthy_joint_observer(GJ, GJ.jointMap, sink_opr, Sigma_o, Sigma_ins, Sigma_era);
if iscell(GSJ) && numel(GSJ) >= 6
    meta = GSJ{6};
    if isfield(meta, 'new2old')
        SJ_jointMap = GJ.jointMap(meta.new2old+1, :);
    else
        SJ_jointMap = GJ.jointMap;
    end
else
    SJ_jointMap = getfield_safe(GJ, 'jointMap', []);
end

if iscell(GSJ)
    n_SJ = GSJ{1}; T_SJ = GSJ{3};
else
    n_SJ = getfield_safe(GSJ, 'n', NaN);
    T_SJ = getfield_safe(GSJ, 'T', []);
end
fprintf('\n===== Stealthy Joint Observer (SJ) Statistics =====\n');
fprintf('SJ states count       : %d\n', n_SJ);
fprintf('SJ transitions count  : %d\n', size(T_SJ, 1));

%% 7) Trim stealthy SJ into GSJ1_A and GSJ1_B
if opts.verbose, fprintf('7) Trim stealthy joint observer into GSJ1_A / GSJ1_B ...\n'); end
[GSJ1_A, GSJ1_B] = build_trimmed_stealthy_joint_observer(GSJ, Sigma_o, Sigma_ins, Sigma_era, SJ_jointMap, opr_card);

fprintf('\n===== Stealthy Trimmed Observers =====\n');
if iscell(GSJ1_A), fprintf('GSJ1_A states count       : %d\n', GSJ1_A{1}); end
if iscell(GSJ1_A), fprintf('GSJ1_A transitions count  : %d\n', size(GSJ1_A{3}, 1)); end
if iscell(GSJ1_B), fprintf('GSJ1_B states count       : %d\n', GSJ1_B{1}); end
if iscell(GSJ1_B), fprintf('GSJ1_B transitions count  : %d\n', size(GSJ1_B{3}, 1)); end

%% 8) prepare y-sets for attacker/operator views
y_att_sets = y;
n_opr = G_opr{1};
y_opr_sets = cell(1, n_opr);
for j = 1:nd_base,         y_opr_sets{j} = y{j}; end
for j = nd_base+1:n_opr,   y_opr_sets{j} = [];   end

if opts.verbose
    try
        print_states_ysets(GSJ,  y_att_sets, y_opr_sets, [], 'SJ states mapped to y-sets');
        print_transitions_ysets(GSJ, y_att_sets, y_opr_sets, [], 'SJ transitions with y-sets');
    catch ME
        if opts.verbose
            warning('print_states_ysets/print_transitions_ysets failed: %s', ME.message);
        end
    end
end

%% 9) check successful attacker (main analysis)
if opts.verbose, fprintf('11) Check existence of successful attacker (this may explore cycles)...\n'); end
obs_state_card = cellfun(@numel, y);
opts_check = struct();
opts_check.max_cycle_len = opts.max_cycle_len;
opts_check.verbose = opts.verbose;

res = check_successful_attacker(Gd, GSJ1_A, GSJ1_B, opr_card, obs_state_card, opts_check);

if opts.verbose
    disp('--- check_successful_attacker result ---');
    disp(res);
end

%% 10) 后续步骤（preemptive sets / online synthesis 等）暂不需要，全部注释掉
%{
%% 10) compute preemptive sets (Qp etc.) on both GSJ1_A and GSJ1_B
setsA = compute_preemptive_sets(GJ, GSJ, GSJ1_A, Sigma_o, Sigma_ins, Sigma_era);
setsB = compute_preemptive_sets(GJ, GSJ, GSJ1_B, Sigma_o, Sigma_ins, Sigma_era);

...

%% 11) [改写] 先判断 C1/C2，再按需进行在线合成（A/B）

...

%% 12) return outputs
out = struct();
out.Gd = Gd;
out.y = y;
out.G_att = G_att;
out.G_opr = G_opr;
out.GJ = GJ;
out.GSJ = GSJ;
out.GSJ1_A = GSJ1_A;
out.GSJ1_B = GSJ1_B;
out.opr_card = opr_card;
out.setsA = setsA;
out.setsB = setsB;
out.attacker_demo_seq_A      = selected_seq_A;
out.attacker_demo_seq_str_A  = selected_seq_str_A;
out.attacker_demo_seq_B      = selected_seq_B;
out.attacker_demo_seq_str_B  = selected_seq_str_B;
out.res = res;
%}

%% 精简版：只返回到第 9 步相关的结果
out = struct();
out.Gd       = Gd;
out.y        = y;
out.G_att    = G_att;
out.G_opr    = G_opr;
out.GJ       = GJ;
out.GSJ      = GSJ;
out.GSJ1_A   = GSJ1_A;
out.GSJ1_B   = GSJ1_B;
out.opr_card = opr_card;
out.res      = res;

end

% ---------------------- Helper local function ---------------------------
function v = getfield_safe(s, fld, defaultVal)
try
    if isstruct(s) && isfield(s, fld)
        v = s.(fld);
    elseif isobject(s) && isprop(s, fld)
        v = s.(fld);
    else
        v = defaultVal;
    end
catch
    v = defaultVal;
end
end
