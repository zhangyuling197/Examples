function [result, errMsg] = run_batch_pipeline_fixed(Gn, opts)
% RUN_BATCH_PIPELINE_FIXED  (single NFA version)
% 仅处理一个 NFA；不做并行。在 A(建观测器) 后做“早检”，
% 未通过则直接返回；通过才继续 B/C/D 并调用 check_successful_attacker。
%
% 返回:
%   result: struct with fields
%     nfa_n, nfa_T, gd_n, gj_n, gsj_n
%     tA, tB, tC, tD, total
%     exists_attack (logical)
%     early_note (string)
%   errMsg: 出错信息（为空表示成功）

    if nargin < 2 || isempty(opts)
        opts = struct('max_cycle_len', 12, 'verbose', false);
    end

    result = struct(); errMsg = '';

    if isempty(Gn)
        errMsg = 'Empty Gn';
        return;
    end

    % ===== 基础信息 =====
    try
        result.nfa_n = double(Gn{1});
        T            = Gn{3};
        result.nfa_T = size(T,1);
    catch ME
        errMsg = sprintf('Malformed Gn basics: %s', ME.message);
        return;
    end

    % ===== 解析 Sigma 集 =====
    try
        [Sigma_o, Sigma_ins, Sigma_era] = extract_sigma_sets(Gn);
    catch ME
        errMsg = sprintf('Extract Sigma sets failed: %s', ME.message);
        return;
    end

    % ===== A) NFA -> Gd =====
    try
        tA = tic;
        [Gd, y] = NFA2DFA(Gn);
        Gd = normalize_Td_symbols_zero_based(Gd);
        tA = toc(tA);
        result.tA   = tA;
        result.gd_n = double(Gd{1});
    catch ME
        errMsg = sprintf('A: NFA->Gd failed: %s', ME.message);
        return;
    end

    % ===== 早检：既有全单点环(Detectable) 又有 非单点环(Undetectable) =====
    try
        n_obs   = double(Gd{1});
        Td_obs  = double(Gd{3});       % [src, sym, dst], sym 已 0-based
        adj_obs = loc_build_adj_list_from_Gd(n_obs, Td_obs);

        maxL    = opts.max_cycle_len;
        cyc_obs = loc_enum_simple_cycles(adj_obs, maxL);

        obs_state_card = cellfun(@numel, y);

        has_detectable   = false;
        has_undetectable = false;
        for i_c = 1:numel(cyc_obs)
            cyc = cyc_obs{i_c};               % 0-based
            cards = obs_state_card(cyc+1);    % y 为 1-based
            if all(cards == 1)
                has_detectable = true;
            else
                has_undetectable = true;
            end
            if has_detectable && has_undetectable, break; end
        end

        if ~(has_detectable && has_undetectable)
            % 不满足假设3：直接返回（仅 A 段时间）
            result.tB = 0; result.tC = 0; result.tD = 0;
            result.total = result.tA;
            result.gj_n = 0; result.gsj_n = 0;
            result.exists_attack = false;
            result.early_note = 'Note: The considered NFA does not satisfy Assumption 3 (detectable but NOT eventually strongly detectable). No attacker exists.';
            return;
        end
    catch ME
        errMsg = sprintf('Early-check failed: %s', ME.message);
        return;
    end

    % ===== B) Gd -> GJ =====
    try
        tB = tic;
        G_att = build_attacker_observer(Gd, Sigma_ins, Sigma_era);
        G_opr = build_operator_observer(Gd, Sigma_ins, Sigma_era);
        if iscell(G_att), G_att{4} = 0; end
        if iscell(G_opr), G_opr{4} = 0; end
        GJ = build_joint_observer(G_att, G_opr);
        tB = toc(tB);
        result.tB = tB;
        if iscell(GJ), result.gj_n = double(GJ{1}); else, result.gj_n = double(GJ.n); end
    catch ME
        errMsg = sprintf('B: Gd->GJ failed: %s', ME.message);
        return;
    end

    % ===== C) GJ -> GSJ =====
    try
        tC = tic;

        sink_opr = detect_operator_sink(G_opr);

        nd_base = double(Gd{1}); nd_opr = double(G_opr{1});
        opr_card = zeros(1, nd_opr);
        for j = 0:nd_base-1
            opr_card(j+1) = numel(y{j+1});
        end
        if ~isempty(sink_opr)
            opr_card(double(sink_opr)+1) = 0;
        end

        jointMap_src = get_jointmap_source(GJ);
        GSJ = build_stealthy_joint_observer(GJ, jointMap_src, sink_opr, Sigma_o, Sigma_ins, Sigma_era);

        tC = toc(tC);
        result.tC = tC;
        if iscell(GSJ), result.gsj_n = double(GSJ{1}); else, result.gsj_n = double(GSJ.n); end
    catch ME
        errMsg = sprintf('C: GJ->GSJ failed: %s', ME.message);
        return;
    end

    % ===== D) GSJ -> Trim & check =====
    try
        tD = tic;

        SJ_jointMap = get_jointmap_safe(GJ, GSJ);
        [GSJ1_A, GSJ1_B] = build_trimmed_stealthy_joint_observer( ...
            GSJ, Sigma_o, Sigma_ins, Sigma_era, SJ_jointMap, opr_card);

        obs_state_card = cellfun(@numel, y);
        res = check_successful_attacker(Gd, GSJ1_A, GSJ1_B, opr_card, obs_state_card, opts);

        tD = toc(tD);
        result.tD = tD;
        result.total = result.tA + result.tB + result.tC + result.tD;
        result.exists_attack = logical(res.exists_attack);
        result.early_note = '';
    catch ME
        errMsg = sprintf('D: trim&check failed: %s', ME.message);
        return;
    end
end

% =================== 工具函数（可另存 .m） ===================

function [Sigma_o, Sigma_ins, Sigma_era] = extract_sigma_sets(Gn)
    Efull = Gn{2};
    if ischar(Efull) || (isstring(Efull) && isscalar(Efull))
        E_cell = cellstr(num2cell(char(Efull)));
    elseif iscell(Efull)
        E_cell = Efull;
    else
        error('Alphabet Gn{2} must be char/string/cellstr.');
    end
    Sigma_o   = normalize_one(E_cell, Gn{6});
    Sigma_ins = normalize_one(E_cell, Gn{7});
    Sigma_era = normalize_one(E_cell, Gn{8});
    Sigma_o   = unique(Sigma_o,  'stable');
    Sigma_ins = unique(Sigma_ins,'stable');
    Sigma_era = unique(Sigma_era,'stable');
end

function S = normalize_one(E_cell, raw)
    if ischar(raw) || (isstring(raw) && isscalar(raw))
        S = cellstr(num2cell(char(raw)));
    elseif iscell(raw)
        S = raw;
    elseif isnumeric(raw) || islogical(raw)
        idx = unique(double(raw(:)),'stable');
        if any(idx < 1) || any(idx > numel(E_cell))
            error('Index out of range while mapping sigma-set.');
        end
        S = E_cell(idx);
    else
        error('Unsupported sigma-set type.');
    end
end

function jointMap_src = get_jointmap_source(GJ)
    if iscell(GJ) && numel(GJ)>=6 && isstruct(GJ{6}) && isfield(GJ{6},'jointMap')
        jointMap_src = GJ{6}.jointMap;
    elseif isstruct(GJ) && isfield(GJ,'jointMap')
        jointMap_src = GJ.jointMap;
    else
        error('GJ.jointMap not found.');
    end
end

function SJ_jointMap = get_jointmap_safe(GJ, GSJ)
    if ~iscell(GSJ) || numel(GSJ) < 6 || ~isstruct(GSJ{6}) || ~isfield(GSJ{6},'new2old')
        error('GSJ meta.new2old missing.');
    end
    meta = GSJ{6};
    idx = double(meta.new2old(:));
    if any(idx < 0)
        error('new2old indices must be >= 0.');
    end
    jointMap_src = get_jointmap_source(GJ);
    if any(idx+1 > size(jointMap_src,1))
        error('new2old contains out-of-range indices.');
    end
    SJ_jointMap = jointMap_src(idx+1, :);
end

function adj = loc_build_adj_list_from_Gd(n_obs, Td_obs)
    adj = cell(n_obs,1);
    for i=1:n_obs, adj{i} = []; end
    for r = 1:size(Td_obs,1)
        s = Td_obs(r,1); t = Td_obs(r,3);
        adj{s+1}(end+1) = t; %#ok<AGROW>
    end
end

function cycles = loc_enum_simple_cycles(adj, maxlen)
    n = numel(adj); cycles = {};
    for start = 0:n-1
        dfs(start, start, start, [], false(1,n));
    end
    function dfs(startNode, prev, cur, path, used)
        path2 = [path, cur]; %#ok<AGROW>
        if numel(path2) > maxlen, return; end
        used2 = used; used2(cur+1) = true;
        neigh = adj{cur+1};
        for v = neigh
            v = double(v);
            if v == startNode && ~isempty(path2)
                cyc = path2;
                mn = min(cyc);
                idx = find(cyc==mn,1);
                cyc_rot = [cyc(idx:end) cyc(1:idx-1)];
                if cyc_rot(1) == startNode
                    if ~exists_cycle_local(cycles, cyc)
                        cycles{end+1} = cyc; %#ok<AGROW>
                    end
                end
            elseif v > startNode && ~used2(v+1)
                dfs(startNode, cur, v, path2, used2);
            end
        end
    end
end

function tf = exists_cycle_local(cycles, cyc)
    tf=false;
    for k=1:numel(cycles)
        if isequal(cycles{k}, cyc), tf=true; return; end
    end
end
