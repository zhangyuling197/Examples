function cycles = list_cycles_johnson(n, Td)
    adj = build_adj_from_Td(n, Td);

    cycles    = {};
    blocked   = false(1,n);
    B         = cell(1,n);
    stack     = zeros(1,n);
    stack_len = 0;

    for s = 0:n-1
        [adj_s, keep] = subgraph_ge(adj, s);
        sccs = tarjan_scc_masked(adj_s, keep);
        % 只考虑包含 s 的强连通部分（Johnson 的“最小索引顶点”策略）
        for kk = 1:numel(sccs)
            comp = sccs{kk};
            if ~ismember(s, comp), continue; end
            for v = comp
                blocked(v+1) = false;
                B{v+1} = [];
            end
            stack_len = 0;
            cycles = circuit(s, s, adj, blocked, B, stack, stack_len, cycles, comp); %#ok<NASGU,ASGLU>
        end
    end

    function [new_cycles, found] = circuit(v, s, adjAll, blocked, B, stack, stack_len, new_cycles, comp_set)
        % 递归搜索从 v 出发回到 s 的简单环（仅在 comp_set 子图内）
        found = false;
        stack_len = stack_len + 1;
        stack(stack_len) = v;
        blocked(v+1) = true;

        nbrs = adjAll{v+1};
        for w = nbrs
            if ~ismember(w, comp_set); continue; end
            if w == s
                % 发现环：stack(1:stack_len) 是一条 simple cycle
                cyc = stack(1:stack_len);
                new_cycles{end+1} = cyc; %#ok<AGROW>
                found = true;
            elseif ~blocked(w+1)
                [new_cycles, got] = circuit(w, s, adjAll, blocked, B, stack, stack_len, new_cycles, comp_set);
                if got, found = true; end
            end
        end

        if found
            % 解除 blocking
            [blocked, B] = unblock(v, blocked, B);
        else
            % 记录阻塞
            for w = nbrs
                if ~ismember(w, comp_set); continue; end
                if ~ismember(v, B{w+1})
                    B{w+1} = [B{w+1}, v];
                end
            end
        end

        stack_len = stack_len - 1; %#ok<NASGU>
    end

    function [blocked, B] = unblock(u, blocked, B)
        blocked(u+1) = false;
        while ~isempty(B{u+1})
            w = B{u+1}(end);
            B{u+1}(end) = [];
            if blocked(w+1)
                [blocked, B] = unblock(w, blocked, B);
            end
        end
    end
end

function adj = build_adj_from_Td(n, Td)
    adj = cell(1,n);
    for r = 1:size(Td,1)
        s = Td(r,1); t = Td(r,3);
        if isempty(adj{s+1})
            adj{s+1} = int32(t);
        else
            if ~ismember(int32(t), adj{s+1})
                adj{s+1}(end+1) = int32(t); %#ok<AGROW>
            end
        end
    end
    % 保证非空 cell
    for i=1:n
        if isempty(adj{i}), adj{i} = int32([]); end
    end
end

function [adj_s, keep] = subgraph_ge(adj, s)
    n = numel(adj);
    keep = false(1,n);
    keep((s+1):n) = true;
    adj_s = cell(1,n);
    for i=0:n-1
        if ~keep(i+1), adj_s{i+1} = int32([]); continue; end
        nbrs = adj{i+1};
        nbrs = nbrs(nbrs>=s);      % 只保留 >= s 的后继
        adj_s{i+1} = nbrs;
    end
end

function sccs = tarjan_scc_masked(adj, keepMask)
    % Tarjan SCC，忽略 keepMask=false 的结点
    n = numel(adj);
    index = 0;
    indices = -ones(1,n);
    lowlink = zeros(1,n);
    onstack = false(1,n);
    S = [];

    sccs = {};
    for v=0:n-1
        if nargin>=2 && ~keepMask(v+1), continue; end
        if indices(v+1) == -1
            strongconnect(v);
        end
    end

    function strongconnect(v)
        index = index + 1;
        indices(v+1) = index;
        lowlink(v+1) = index;
        S(end+1) = v; %#ok<AGROW>
        onstack(v+1) = true;

        for w = adj{v+1}
            if nargin>=2 && ~keepMask(w+1), continue; end
            if indices(w+1) == -1
                strongconnect(w);
                lowlink(v+1) = min(lowlink(v+1), lowlink(w+1));
            elseif onstack(w+1)
                lowlink(v+1) = min(lowlink(v+1), indices(w+1));
            end
        end

        if lowlink(v+1) == indices(v+1)
            % pop stack until v
            comp = [];
            while true
                w = S(end); S(end) = [];
                onstack(w+1) = false;
                comp(end+1) = w; %#ok<AGROW>
                if w == v, break; end
            end
            sccs{end+1} = sort(comp); %#ok<AGROW>
        end
    end
end
