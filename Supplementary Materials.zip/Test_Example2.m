%% NFA for the figure 8
n = 6;
E = {'a','b','c','d','e'};   % a=1, b=2, c=3, d=4, e=5;  epsilon=0

% T rows are [from_state, event_index, to_state]
T = [
    % state 0 (-> 1)
    1, 3, 1;   % 0 --c--> 0
    1, 0, 2;   % 0 --ε--> 1
    1, 1, 4;   % 0 --a--> 3
    1, 4, 6;   % 0 --d--> 5
    1, 2, 5;   % 0 --b--> 4
    1, 5, 5;   % 0 --e--> 4

    % state 1 (-> 2)
    2, 1, 3;   % 1 --a--> 2

    % state 2 (self-loop on c)
    3, 3, 3;   % 2 --c--> 2

    % state 3 (self-loop on c)
    4, 3, 4;   % 3 --c--> 3

    % state 5 (-> 4, self-loop on c)
    6, 2, 5;   % 5 --b--> 4
    6, 3, 6;   % 5 --c--> 5

    % state 4 (self-loop on c)
    5, 3, 5;   % 4 --c--> 4
];

X0 = [1];     % initial state is node 0 in the figure
Xm = [];      % (no marked states in the figure)
Gn = {n, E, T, X0, Xm};

% (可按需要设置观测/可插入/可擦除事件)
Sigma_o   = {'a','b','c','d','e'};  % 全部可观测（如需与论文设定一致可改）
Sigma_ins = {};                      % 可插入事件（按需）
Sigma_era = {'d','e'};                      % 可擦除事件（按需）

clear opts;
opts = struct();
opts.verbose = true;
opts.max_cycle_len = 30;
%opts.in_seq = {'a','b','c','a','b','c'};   % 可选：若省略，函数会使用内置默认序列
out = run_attack_demo(Gn, Sigma_o, Sigma_ins, Sigma_era, opts);
