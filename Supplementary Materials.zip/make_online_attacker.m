function attacker = make_online_attacker(GSJ1, Sigma_o, Sigma_ins, Sigma_era, Qp_mask, varargin)
% MAKE_ONLINE_ATTACKER  (online) synthesis of a successful attacker f_A
% Implements Algorithm "Synthesis of a Successful Attacker f_A"
%
% Inputs
%   GSJ1      : trimmed stealthy joint observer {n1, Ed1, T1, init1, [], meta}
%   Sigma_o   : cellstr of base observable symbols, e.g., {'a','b','c'}
%   Sigma_ins : cellstr of insertable base symbols, e.g., {'a'}
%   Sigma_era : cellstr of erasable base symbols, e.g., {'a','b'}
%   Qp_mask   : 1 x n1 logical for preemptive states Q_{S,1}^p (from你的Qp计算)
%
% Optional name-value:
%   'InsertPolicy' : 'minimal' (default) | 'always'  (在非预防态是否插入)
%   'MaxInsertLen' : positive integer (默认 1)，插入串 w_{a,+} 最长长度
%
% Usage
%   atk = make_online_attacker(GSJ1, Sigma_o, Sigma_ins, Sigma_era, Qp_mask);
%   atk.init();                        % 步骤1–3
%   out = atk.step('a');               % 输入一个可观事件 e='a'，返回 cellstr 输出序列
%   [q_s, w] = atk.state();            % 查看内部在线状态

% ----- params / options -----
p = inputParser;
addParameter(p, 'InsertPolicy', 'minimal');   % 'minimal' or 'always'
addParameter(p, 'MaxInsertLen', 1);
parse(p, varargin{:});
insertPolicy = validatestring(p.Results.InsertPolicy, {'minimal','always'});
maxInsertLen = max(1, round(p.Results.MaxInsertLen));

% ----- unpack GSJ1 -----
n1   = double(GSJ1{1});
Ed1  = GSJ1{2};
T1   = double(GSJ1{3});   % [src, sym, dst] (0-based)
q0   = double(GSJ1{4});   % 0-based

% ----- symbol maps (exact match, e.g., 'a_+', 'a_-') -----
sym2idx = containers.Map();
for k = 1:numel(Ed1), sym2idx(Ed1{k}) = int32(k-1); end

% helper: get symbol id in GSJ1 alphabet
    function id = idS(symname)
        if isKey(sym2idx, symname), id = double(sym2idx(symname));
        else, id = -1; end
    end

% ----- per-state delta -----
delta = cell(n1,1);
for r = 1:size(T1,1)
    s = T1(r,1); a = T1(r,2); t = T1(r,3);
    if isempty(delta{s+1})
        delta{s+1} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta{s+1}(int32(a)) = int32(t);
end

% ----- convenience: apply a string (cellstr of exact symbols in Ed1) -----
    function [q_next, ok] = apply_string(q_from, str_syms)
        q_next = q_from; ok = true;
        for ii = 1:numel(str_syms)
            a = idS(str_syms{ii});
            if a < 0 || isempty(delta{q_next+1}) || ~isKey(delta{q_next+1}, int32(a))
                ok = false; return;
            end
            q_next = double(delta{q_next+1}(int32(a)));
        end
    end

% ----- enumerate enabled Σ_+ at a state -----
Sigma_plus_full = strcat(Sigma_ins, '_+');  % {'a_+','b_+',...}

    function en = enabled_plus(q)
        en = {};
        if isempty(delta{q+1}), return; end
        for i = 1:numel(Sigma_plus_full)
            a = idS(Sigma_plus_full{i});
            if a >= 0 && isKey(delta{q+1}, int32(a))
                en{end+1} = Sigma_plus_full{i}; %#ok<AGROW>
            end
        end
    end

% ----- pick an insert string w_{a,+} \in W_+(q) -----
% 简化策略：优先选择长度<=MaxInsertLen 的最短非空串；若没有则返回 {}(epsilon)
    function wplus = pick_insert_string(q)
        if maxInsertLen <= 0, wplus = {}; return; end
        % 先尝试一步插入
        plus1 = enabled_plus(q);
        if ~isempty(plus1)
            wplus = plus1(1);   % 任选其一（可根据你目标进一步优化）
            return;
        end
        % 如需更长插入（BFS），可按需要开启（默认 MaxInsertLen=1 不走这里）
        if maxInsertLen == 1
            wplus = {}; return;
        end
        % 简单 BFS over Σ_+ up to MaxInsertLen
        Q = { {q, {}} };             % each item: {state, seq}
        visited = containers.Map('KeyType','char','ValueType','logical');
        key0 = sprintf('%d|', q); visited(key0) = true;
        while ~isempty(Q)
            item = Q{1}; Q(1) = [];
            cur = item{1}; seq = item{2};
            if ~isempty(seq)
                wplus = seq; return; % shortest found
            end
            if numel(seq) >= maxInsertLen, continue; end
            plist = enabled_plus(cur);
            for i = 1:numel(plist)
                a = plist{i};
                a_id = idS(a);
                cur2 = double(delta{cur+1}(int32(a_id)));
                seq2 = [seq, {a}];
                key  = sprintf('%d|%s|', cur2, strjoin(seq2,'-'));
                if ~isKey(visited, key)
                    visited(key) = true;
                    Q{end+1} = {cur2, seq2}; %#ok<AGROW>
                end
            end
        end
        wplus = {};  % no insertion available
    end

% ----- choose e' in {e, e_-} that is enabled at q -----
    function [eprime_sym, q_after, ok] = choose_eprime(q, e_base)
        % prefer e first; if not enabled, try e_-
        e_id  = idS(e_base);
        e_m   = [e_base, '_-'];
        em_id = idS(e_m);

        if e_id >= 0 && ~isempty(delta{q+1}) && isKey(delta{q+1}, int32(e_id))
            q_after = double(delta{q+1}(int32(e_id)));
            eprime_sym = e_base; ok = true; return;
        end
        if em_id >= 0 && ~isempty(delta{q+1}) && isKey(delta{q+1}, int32(em_id))
            q_after = double(delta{q+1}(int32(em_id)));
            eprime_sym = e_m; ok = true; return;
        end
        eprime_sym = ''; q_after = q; ok = false;
    end

% ==================== internal state (Algorithm variables) ====================
q_s = q0;         % current GSJ1 state
w   = {};         % cumulative observation (cellstr of base events) -- optional

% ==================== exported API ====================
    function init()
        % Steps 1–3: choose initial w_{a,+} and update q_s
        wplus0 = pick_insert_string(q_s);          % w_{a,+} \in W_+(q_{s1,0})
        if ~isempty(wplus0)
            [q_s2, ok] = apply_string(q_s, wplus0);
            if ok, q_s = q_s2; end
        end
    end

    function out = step(e_base)
        % One online step for an observable input e \in Σ_o
        % Returns 'out': cellstr of symbols actually issued by attacker
        %   out = {e'}                    OR
        %   out = {e', w_{a,+}(1), ...}  (if we append an inserted string)
        out = {};
        % ---- Step 4: wait for e (here e_base is given) ----

        % ---- Step 5: pick e' in {e, e_-} s.t. δ(q_s, e')! and get \hat{q}_s ----
        [eprime, q_hat, ok] = choose_eprime(q_s, e_base);
        if ~ok
            % 若都不可用：保持静默，不改变状态（或你可以自行定义为报错）
            warning('No enabled transition for {%s,%s_-} at state %d; staying put.', e_base, e_base, q_s);
            return;
        end

        % ---- Step 6: compute W_+(\hat{q}_s) and pick \hat{w}_{a,+} ----
        wplus_hat = pick_insert_string(q_hat);

        % ---- Steps 7–10: choose attack string by preemptive / non-preemptive ----
        if Qp_mask(q_hat+1)
            % preemptive: use e' \hat{w}_{a,+}
            out = [{eprime}, wplus_hat];
            q_s = q_hat;
            if ~isempty(wplus_hat)
                [q_s2, ok2] = apply_string(q_s, wplus_hat);
                if ok2, q_s = q_s2; end
            end
        else
            % non-preemptive: policy
            if strcmp(insertPolicy, 'always') && ~isempty(wplus_hat)
                out = [{eprime}, wplus_hat];
                q_s = q_hat;
                [q_s2, ok2] = apply_string(q_s, wplus_hat);
                if ok2, q_s = q_s2; end
            else
                out = {eprime};
                q_s = q_hat;
            end
        end

        % ---- Step 11: update observation w <- we (仅记录 base e) ----
        w{end+1} = e_base;
    end

    function [qs, w_hist] = state()
        qs = q_s; w_hist = w;
    end

% return struct “对象”
attacker.init  = @init;
attacker.step  = @step;
attacker.state = @state;
end
