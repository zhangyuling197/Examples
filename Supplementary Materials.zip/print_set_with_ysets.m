function print_set_with_ysets(GSJ1, mask_or_idx, y_att_sets, y_opr_sets, title_str)
% 打印形如：
% Qp1 (idx 0-based):  0 3 4
%   0 : ({1} , {1})
%   3 : ({2 5} , {2 5})
%   4 : ({6} , {6})
%
% mask_or_idx 可以是 1×n 的 logical mask，或 0-based 索引向量

    if nargin < 5 || isempty(title_str), title_str = 'Set'; end
    n1 = GSJ1{1};
    jm = GSJ1{6}.jointMap;   % n1 x 2 (0-based att, opr)

    % 标准化为 0-based 索引列向量
    if islogical(mask_or_idx)
        idx0 = find(mask_or_idx) - 1;
    else
        idx0 = mask_or_idx(:).';
    end

    % 先打印索引行
    fprintf('%s (idx 0-based): ', title_str);
    if isempty(idx0)
        fprintf('[]\n');
        return;
    else
        fprintf('%s\n', sprintf('%d ', idx0));
    end

    % 逐个状态打印 y-sets
    for k = idx0
        s = k;                              % 0-based state in GSJ1
        qa = jm(s+1, 1); qo = jm(s+1, 2);   % 0-based indices in att/opr observers
        Ya = set_to_str(y_att_sets{qa+1});
        Yo = set_to_str(y_opr_sets{qo+1});
        fprintf('  %d : (%s , %s)\n', s, Ya, Yo);
    end
end
