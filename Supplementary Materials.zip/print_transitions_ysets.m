function print_transitions_ysets(GSJ, y_att_sets, y_opr_sets, ~, title_str)
% print_transitions_ysets
% 打印每条转移及其 y-sets (attacker/operator)
% 自动容忍空图、jointMap 缺失、索引越界、不一致长度等情况。
%
% 输出格式:
%   ({Ya_s} , {Yo_s}) -- event --> ({Ya_t} , {Yo_t})
%
% 示例:
%   print_transitions_ysets(GSJ1_B, y_att_sets, y_opr_sets, [], 'GSJ1_B transitions with y-sets');

if nargin < 5 || isempty(title_str), title_str = 'Transitions with y-sets'; end
fprintf('\n===== %s =====\n', title_str);

%% --- 情况1：空 GSJ 或结构缺失 ---
if isempty(GSJ) || ~iscell(GSJ) || numel(GSJ) < 6
    fprintf('(empty GSJ)\n');
    return;
end

try
    n = double(GSJ{1});
    Ed = GSJ{2};
    Td = GSJ{3};
    meta = GSJ{6};
catch
    fprintf('(invalid GSJ structure)\n');
    return;
end

if isempty(Td) || n == 0
    fprintf('(∅)\n');
    return;
end

%% --- 情况2：jointMap 缺失 ---
if ~isstruct(meta) || ~isfield(meta,'jointMap') || isempty(meta.jointMap)
    fprintf('(jointMap missing) -> (∅)\n');
    return;
end
jointMap = meta.jointMap;

%% --- 主循环输出 ---
for r = 1:size(Td,1)
    s = Td(r,1); a = Td(r,2); t = Td(r,3);

    % 检查索引有效性
    if s+1 > size(jointMap,1) || t+1 > size(jointMap,1)
        continue;
    end

    qa_s = jointMap(s+1,1);
    qo_s = jointMap(s+1,2);
    qa_t = jointMap(t+1,1);
    qo_t = jointMap(t+1,2);

    % 获取 y-sets (兼容缺失)
    Ya_s = safe_get_yset(y_att_sets, qa_s+1);
    Yo_s = safe_get_yset(y_opr_sets, qo_s+1);
    Ya_t = safe_get_yset(y_att_sets, qa_t+1);
    Yo_t = safe_get_yset(y_opr_sets, qo_t+1);

    % 获取符号名
    symName = '(?)';
    if a+1 >= 1 && a+1 <= numel(Ed)
        try
            symName = Ed{a+1};
        catch
        end
    end

    % 打印结果
    fprintf('({%s} , {%s}) -- %s --> ({%s} , {%s})\n', Ya_s, Yo_s, symName, Ya_t, Yo_t);
end
end

%% --- 辅助函数 ---
function out = safe_get_yset(ysets, idx)
% 安全访问 cell 中的 y_set，并转换为字符串
if idx < 1 || idx > numel(ysets) || isempty(ysets{idx})
    out = '';
    return;
end
val = ysets{idx};
if isnumeric(val)
    out = strtrim(num2str(val));
elseif iscell(val)
    out = strjoin(string(val), ' ');
else
    out = string(val);
end
end
