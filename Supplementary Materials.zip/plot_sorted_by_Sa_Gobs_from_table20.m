function plot_sorted_by_Sa_Gobs_from_table20()
% 按 W = (|Sigma_o|+|Sigma_ins|+|Sigma_era|) * |G_obs| 升序排序
% 绘制 |G_J| 与 T_final 的变化（来源：给定20行表格）

%% ====== 把表格数据录入为数组 ======
% 行次 1..20
X      = [17 17 18 20 18 22 25 22 25 21 20 21 25 30 19 16 29 16 28 15];
Tr     = [49 43 46 41 48 63 61 61 76 43 45 53 87 79 60 46 55 40 52 30];

So     = [2 2 2 2 1 2 2 2 2 1 2 1 2 1 2 2 2 2 2 1];
Sins   = [1 1 1 1 0 1 1 1 1 0 1 0 1 0 1 1 1 1 1 0];
Sera   = [1 1 1 1 0 1 1 1 1 0 1 0 1 0 1 1 1 1 1 0];

Gobs   = [62 40 94 38 275 54 35 73 155 62 21 154 110 468 98 131 29 30 30 39];
GJ     = [ 0 394 2175 120 275 456 227 701 3403  62  93 154 1774   0 1677 4287   0 255   0  39];
GSJ    = [ 0 103 1055  65 275 226 124 275 1749  62  80 154  999   0  811 3402   0  88   0  39];

Tobs   = [0.13 0.07 0.15 0.07 0.62 0.10 0.05 0.13 0.30 0.07 0.54 0.86 0.79 1.77 0.77 0.87 0.54 0.51 0.53 0.52];
TJ     = [  0  0.35 1.89 0.26 0.35 0.46 0.23 0.74 3.45 0.09 0.32 0.40 2.06   0  1.90 3.98   0 0.52   0 0.21];
TSJ    = [  0  0.14 1.07 0.20 0.09 0.17 0.08 0.25 1.76 0.02 0.14 0.16 0.85   0  0.74 2.36   0 0.21   0 0.12];

Tfinal = [0.13 4.82 8.89 0.87 1.69 3.59 1.56 9.72 106.46 0.32 1.94 2.30 125.03 1.77 9852.61 2041.15 0.54 2.42 0.53 1.09];

%% ====== 计算 Σ_a 与权重 W ======
Sa = So + Sins + Sera;         % |Σ_a|
W  = Sa .* Gobs;               % W = |Σ_a| * |G_obs|
%W  = Sa .* (Gobs.^2);             % W = |Σ_a| * |G_obs|^2
%% ====== 排除 G_J = 0 的样本（对应表格中的“–”）=====
valid = (GJ > 0);
W       = W(valid);
GJ      = GJ(valid);
Tfinal  = Tfinal(valid);

%% ====== 按 W 升序排序 ======
[W_sorted, idx] = sort(W, 'ascend');
GJ_sorted = GJ(idx);
Tf_sorted = Tfinal(idx);

%% ====== 绘图 ======
% 图1：|G_J| vs W
figure('Color','w');
plot(W_sorted, GJ_sorted, '-o', 'LineWidth',1.8, 'MarkerSize',7);
grid on;
xlabel('$|\Sigma_a| \times |G_{obs}|$ (ascending)', ...
       'Interpreter', 'latex', 'FontSize', 12);
ylabel('$|G_J|$', 'Interpreter', 'latex', 'FontSize', 12);
% title('$|G_J|$ vs. $|\Sigma_a| \times |G_{obs}|$ (sorted)', ...
%        'Interpreter', 'latex', 'FontSize', 12);

% 可选标注点值：
% for k = 1:numel(W_sorted)
%     text(W_sorted(k), GJ_sorted(k), sprintf('  %.0f', GJ_sorted(k)), 'FontSize',9);
% end

% 图2：T_final vs W
figure('Color','w');
plot(W_sorted, Tf_sorted, '-o', 'LineWidth',1.8, 'MarkerSize',7);
grid on;
xlabel('$|\Sigma_a| \times |G_{obs}|$ (ascending)', ...
       'Interpreter', 'latex', 'FontSize', 12);
ylabel('$T_{\mathrm{final}}~(s)$', 'Interpreter', 'latex', 'FontSize', 12);
% title('$T_{\mathrm{final}}$ vs. $|\Sigma_a| \times |G_{obs}|$ (sorted)', ...
%        'Interpreter', 'latex', 'FontSize', 12);
% 若跨度很大，可打开对数纵轴：
set(gca,'YScale','log');

%% ======（可选）打印排序后的简表 ======
% T = table(W_sorted(:), GJ_sorted(:), Tf_sorted(:), ...
%           'VariableNames', {'Weight','G_J','T_final'});
% disp('=== Sorted by Weight (G_J>0) ===');
% disp(T);
end
