function print_joint_pairs(G_trimmed, GJ_jointMap, new2old)
% G_trimmed: {n,Ed,T,init,...,meta?}
% GJ_jointMap: |Q_J| x 2 的 (q_att,q_opr) 0-based（来自 GJ.jointMap）
% new2old: 1 x n 的 0-based 新→旧 映射（如果 G_trimmed{6} 里没有）

    if iscell(G_trimmed)
        n = G_trimmed{1};
        jm = [];

        % 优先用 meta.jointMap
        if numel(G_trimmed) >= 6 && isstruct(G_trimmed{6}) && isfield(G_trimmed{6},'jointMap')
            jm = G_trimmed{6}.jointMap;

        % 否则用提供的 GJ_jointMap + new2old
        elseif nargin >= 3 && ~isempty(GJ_jointMap) && ~isempty(new2old)
            jm = GJ_jointMap(new2old+1, :);
        else
            error('No joint mapping: pass GJ_jointMap and new2old, or ensure meta.jointMap/new2old exists.');
        end

        for s = 0:n-1
            fprintf('state %-2d : (%d,%d)\n', s, jm(s+1,1), jm(s+1,2));
        end
    else
        error('G_trimmed must be the cell form {n,Ed,T,init,...}.');
    end
end
