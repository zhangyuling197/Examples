function print_attacker_qs_ysets(attacker, y_att_sets, y_opr_sets)
% PRINT_ATTACKER_QS_YSETS  print current attacker.q_s with corresponding y-sets
% attacker: struct from attacker_init_minimal / attacker_init_simple
% y_att_sets, y_opr_sets: cell arrays mapping attacker observer indices -> sets
%                         (these are the y mapping you used earlier)
%
% Example:
%   print_attacker_qs_ysets(attacker, y_att_sets, y_opr_sets)

if ~isfield(attacker, 'q_s')
    error('attacker struct has no field q_s');
end
if ~isfield(attacker.GSJ1{6}, 'jointMap')
    error('attacker.GSJ1 meta missing jointMap');
end

q_s = attacker.q_s;                 % 0-based
jm  = attacker.GSJ1{6}.jointMap;    % n1 x 2 (0-based att, opr)

if q_s < 0 || q_s+1 > size(jm,1)
    fprintf('q_s = %d (out of range)\n', q_s);
    return;
end

qa = jm(q_s+1, 1);  % 0-based attacker-observer index
qo = jm(q_s+1, 2);  % 0-based operator-observer index

% defensive: ensure indices valid for provided y_sets
Ya = {};
Yo = {};
if qa+1 <= numel(y_att_sets) && qa+1 >= 1
    Ya = y_att_sets{qa+1};
end
if qo+1 <= numel(y_opr_sets) && qo+1 >= 1
    Yo = y_opr_sets{qo+1};
end

% format sets to {1 2 3} style
fmt = @(S) (isempty(S) * "{ }" + (~isempty(S)) * ("{ " + strjoin(arrayfun(@num2str, S, 'UniformOutput', false), ' ') + " }"));

% MATLAB doesn't like logical arithmetic for strings in older versions, so:
if isempty(Ya)
    sYa = '{}';
else
    sYa = ['{', strjoin(arrayfun(@num2str, Ya, 'UniformOutput', false), ' '), '}'];
end
if isempty(Yo)
    sYo = '{}';
else
    sYo = ['{', strjoin(arrayfun(@num2str, Yo, 'UniformOutput', false), ' '), '}'];
end

fprintf('q_s = %d  ->  (%s , %s)\n', q_s, sYa, sYo);
end
