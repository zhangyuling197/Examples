function G_opr = build_operator_observer(Gd, Sigma_ins, Sigma_era)
% Operator observer with a deadlocking sink (no outgoing transitions)
% Gd = {nd, Ed, Td, xd0, Xdm}  with 0-based Td
nd   = Gd{1};
Ed_o = Gd{2};
Td   = Gd{3};
xd0  = Gd{4};
Xdm  = Gd{5};

if ischar(Ed_o), Ed_o = arrayfun(@(c){char(c)}, Ed_o); end
if nargin < 2, Sigma_ins = {}; end
if nargin < 3, Sigma_era = {}; end

Sigma_ins = intersect(Sigma_ins, Ed_o, 'stable');
Sigma_era = intersect(Sigma_era, Ed_o, 'stable');

Ed_plus  = cellfun(@(s)[s,'_+'], Sigma_ins, 'UniformOutput', false);
Ed_minus = cellfun(@(s)[s,'_-'], Sigma_era, 'UniformOutput', false);
EdA = [Ed_o, Ed_plus, Ed_minus];

no = numel(Ed_o);
n_plus = numel(Ed_plus);
n_minus = numel(Ed_minus);

% original symbol -> 0-based index
symIndex = containers.Map();
for j = 1:no, symIndex(Ed_o{j}) = j-1; end

% δ_obs for original alphabet (0-based keys)
delta_obs = cell(nd,1);
for r = 1:size(Td,1)
    s = double(Td(r,1)); a = double(Td(r,2)); t = double(Td(r,3));
    ci = s + 1;
    if isempty(delta_obs{ci})
        delta_obs{ci} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta_obs{ci}(int32(a)) = int32(t);
end

sink = nd;   % 0-based sink index (deadlock)
TdA = [];

% 普通状态 0..nd-1 的转移
for q = 0:(nd-1)
    ci = q + 1;
    % Σ_o：已定义 -> 该后继；未定义 -> sink
    for j = 1:no
        aidx = j-1;
        if ~isempty(delta_obs{ci}) && isKey(delta_obs{ci}, int32(aidx))
            dst = double(delta_obs{ci}(int32(aidx)));
        else
            dst = sink;
        end
        TdA(end+1,:) = [q, aidx, dst]; %#ok<AGROW>
    end
    % Σ_+：视作看到 e；未定义 -> sink
    for j = 1:n_plus
        e = Sigma_ins{j}; aidx_orig = symIndex(e);
        if ~isempty(delta_obs{ci}) && isKey(delta_obs{ci}, int32(aidx_orig))
            dst = double(delta_obs{ci}(int32(aidx_orig)));
        else
            dst = sink;
        end
        sym_plus_idx = no + (j-1);
        TdA(end+1,:) = [q, sym_plus_idx, dst]; %#ok<AGROW>
    end
    % Σ_-：看不见 -> 自环（停留）
    for j = 1:n_minus
        sym_minus_idx = no + n_plus + (j-1);
        TdA(end+1,:) = [q, sym_minus_idx, q]; %#ok<AGROW>
    end
end

% 与之前不同：不为 sink 添加任何出边（真正死锁）
% （因此没有：for a=0:(numel(EdA)-1) sink->sink ...）

n_opr = nd + 1;
G_opr = {n_opr, EdA, TdA, xd0, Xdm};
end
