function [Gn_cell, y_sets] = nfa_struct_to_cell_for_observer(G)
% 把结构体例子 G 转为 {n, E, T, X0, Xm} 形式：
%   G.X         = 1..n 的状态编号（行或列向量都可）
%   G.Sigma     = 全符号（cellstr）
%   G.Sigma_o   = 可观符号子集（本函数不强依赖）
%   G.X0        = 初始状态（标量或向量）
%   G.delta     = containers.Map('KeyType','char','ValueType','any')
%                 键形如 'x|sym'，值为后继状态集合（数值向量）
%
% 输出：
%   Gn_cell = {n, E, T, X0, []}，其中 T 为 [src, symIdx, dst]（1-based 状态，symIdx=1..|E|）
%   y_sets  = {} 占位（真实 y 由 NFA2DFA 返回）

    % --- 基本字段 ---
    if ~isfield(G,'X') || ~isfield(G,'Sigma') || ~isfield(G,'X0') || ~isfield(G,'delta')
        error('nfa_struct_to_cell_for_observer: 输入G缺少必要字段 X/Sigma/X0/delta');
    end
    X  = G.X(:)';                 % 统一行向量
    E  = G.Sigma(:)';             % 全符号
    nX = numel(X);
    X0 = G.X0;
    if isempty(X0), X0 = X(1); end

    % --- 符号 -> 索引（1..|E|）---
    sym2idx = containers.Map();
    for k = 1:numel(E)
        sym2idx(E{k}) = k;
    end

    % --- 收集转移 ---
    rows = zeros(0,3);
    keys = G.delta.keys;          % 是 cell array
    for i = 1:numel(keys)
        K = keys{i};              % 'x|sym'
        parts = split(K,'|');     % {'x','sym'}
        if numel(parts) ~= 2
            warning('delta key "%s" 不是 "x|sym" 形式，跳过', K);
            continue;
        end

        % 解析源状态编号
        x = str2double(parts{1});
        if ~isfinite(x)
            warning('delta key "%s" 的源状态不是数值，跳过', K);
            continue;
        end

        % 解析符号并映射到索引
        sym = char(parts{2});
        if ~isKey(sym2idx, sym)
            % 不在字母表中（可能是不可观/额外符号未放入 G.Sigma），跳过
            % 如需保留不可观符号，请把它们也放进 G.Sigma
            continue;
        end
        sid = sym2idx(sym);

        % 取出后继集合（必须先赋值再索引！）
        v = G.delta(K);           % 可能是double/row/col
        if isempty(v), continue; end
        if ~isnumeric(v)
            warning('delta("%s") 的值不是数值向量，跳过', K);
            continue;
        end
        dsts = unique(v(:))';     % 统一为去重行向量

        % 逐一生成三元组
        for d = dsts
            rows(end+1,:) = [x, sid, d]; %#ok<AGROW>
        end
    end

    % --- 输出 ---
    Gn_cell = { nX, E, rows, X0, [] };
    y_sets  = {};                 % 占位（NFA2DFA会返回真实 y）
end
