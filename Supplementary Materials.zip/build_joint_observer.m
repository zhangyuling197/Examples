function GJ = build_joint_observer(G_att, G_opr)
% Joint observer under attacker-gated rule:
% Only if attacker has delta_att(q_att,e) defined, we add
% (q_att,q_opr) -e-> (q_att', q_opr') (and only if operator also has that e).
% Otherwise: no transition.
%
% Inputs G_att, G_opr: cell {n, Ed, Td, init?, ...} or struct with fields
%   .n, .alphabet, .T, .init (all transitions/state indices 0-based)
% Output GJ struct:
%   .n, .alphabet (union, stable), .T [src sym dst] (0-based),
%   .init = [i0 j0], .jointMap (idx->[i j]), .pair2idx (key 'i#j'->idx)

% ---- unpack ----
[nA, EdA, TdA, xA] = unpack_auto(G_att);% 解包G_att；统一cell/struct的格式提取G_att的各个元素
[nO, EdO, TdO, xO] = unpack_auto(G_opr);
EdA = normalize_alphabet(EdA);%事件集最后都统一成 cell 数组形式
EdO = normalize_alphabet(EdO);

% 我们只遍历攻击者字母表上的符号（严格按规则）
EdJ = unique(EdA, 'stable');        % 输出字母表=攻击者字母表
nE  = numel(EdJ);

% 符号到本地索引(0-based)
s2iA = containers.Map(EdA, num2cell(0:numel(EdA)-1));
s2iO = containers.Map(EdO, num2cell(0:numel(EdO)-1));
s2iJ = containers.Map(EdJ, num2cell(0:nE-1));

% 每个状态的转移表（key=本地符号0基索引）
deltaA = build_delta(nA, TdA);
deltaO = build_delta(nO, TdO);

% 初始对（若未给或非法，默认为0）
initA = 0; if ~isempty(xA) && isscalar(xA) && xA>=0 && xA<nA, initA = double(xA); end
initO = 0; if ~isempty(xO) && isscalar(xO) && xO>=0 && xO<nO, initO = double(xO); end

% ---- BFS over reachable pairs ----
pair2idx = containers.Map();
keyfun = @(i,j) sprintf('%d#%d', i, j);
pair2idx(keyfun(initA,initO)) = int32(0);

queue = [initA, initO];
jointPairs = zeros(256,2); jointPairs(1,:) = [initA, initO];
nJ = 1; T = [];

while ~isempty(queue)
    ij = queue(1,:); queue(1,:) = [];
    i = ij(1); j = ij(2);
    ci = i+1; cj = j+1;
    src = double(pair2idx(keyfun(i,j)));

    % 仅遍历攻击者字母表上的事件
    for k = 1:nE
        sym   = EdJ{k};
        aA    = s2iA(sym);                 % 攻击者本地符号索引
        hasOp = isKey(s2iO, sym);          % 操作者是否包含该符号
        % 攻击者必须有该边
        if ci<=numel(deltaA) && ~isempty(deltaA{ci}) && isKey(deltaA{ci}, int32(aA))
            u = double(deltaA{ci}(int32(aA)));   % 攻击者后继
            if hasOp
                aO = s2iO(sym);
                if cj<=numel(deltaO) && ~isempty(deltaO{cj}) && isKey(deltaO{cj}, int32(aO))
                    v = double(deltaO{cj}(int32(aO)));   % 操作者后继
                    % 记录边并注册目标pair
                    [nJ, pair2idx, queue, T, jointPairs] = add_edge(i,j,u,v, s2iJ(sym), nJ, pair2idx, queue, T, keyfun, jointPairs);
                end
            end
            % 若操作者不含该符号或该态无边：按规则不产生转移
        end
    end
end

jointPairs = jointPairs(1:nJ,:);
GJ.n = nJ; GJ.alphabet = EdJ; GJ.T = T; GJ.init = [initA, initO];
GJ.jointMap = jointPairs; GJ.pair2idx = pair2idx;
end

% ---------- helpers ----------
%统一提取G的各元素
function [n,Ed,Td,x0] = unpack_auto(G)
    x0 = [];
    if iscell(G), n=G{1}; Ed=G{2}; Td=G{3}; if numel(G)>=4, x0=G{4}; end
    else, n=G.n; Ed=G.alphabet; Td=G.T; if isfield(G,'init'), x0=G.init; end
    end
    Td = double(Td);
end
%事件集都标准化为cell array
function Ed = normalize_alphabet(Ed)
    if ischar(Ed), Ed = arrayfun(@(c){char(c)}, Ed);
    elseif isstring(Ed), Ed = cellstr(Ed);
    end
end
%输出：一个长度为 n 的元胞数组，delta{i} 记录从状态 i-1 出发的所有事件→目标状态的映射。
function delta = build_delta(n, Td)
    delta = cell(n,1);
    for r = 1:size(Td,1)
        s = double(Td(r,1)); a = double(Td(r,2)); t = double(Td(r,3));
        ci = s + 1;
        if isempty(delta{ci})
            delta{ci} = containers.Map('KeyType','int32','ValueType','int32');
        end
        delta{ci}(int32(a)) = int32(t);
    end
end
%新增联合状态 + 登记其索引 + 入队待处理 + 写入一条从已知源到该目标的转移
function [nJ, pair2idx, queue, T, jointPairs] = add_edge(i,j,u,v,symIdx,nJ,pair2idx,queue,T,keyfun,jointPairs)
    k = keyfun(u,v);
    if ~isKey(pair2idx,k)
        pair2idx(k) = int32(nJ);
        queue(end+1,:) = [u,v];
        if size(jointPairs,1) < nJ+1
            jointPairs = [jointPairs; zeros(max(256,size(jointPairs,1)),2)]; %#ok<AGROW>
        end
        jointPairs(nJ+1,:) = [u,v];
        nJ = nJ + 1;
    end
    src = double(pair2idx(keyfun(i,j)));
    dst = double(pair2idx(k));
    T(end+1,:) = [src, symIdx, dst]; %#ok<AGROW>
end
