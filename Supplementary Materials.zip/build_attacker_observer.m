function G_att = build_attacker_observer(Gd, Sigma_ins, Sigma_era)
% Gd = {nd, Ed, Td, xd0, Xdm}, Td uses 0-based indices (src sym dst)
% Sigma_ins, Sigma_era are cell arrays of original symbols (subset of Ed)
% Attacker observer: do NOT add sink (non-total). EdA = [Ed, e_+ for Sigma_ins, e_- for Sigma_era (only names)]

nd   = Gd{1};
Ed_o = Gd{2};%可观事件集，字符数组
Td   = Gd{3};
xd0  = Gd{4};
Xdm  = Gd{5};

if ischar(Ed_o), Ed_o = arrayfun(@(c){char(c)}, Ed_o); end % 可观事件-->cell array
if nargin < 2, Sigma_ins = {}; end
if nargin < 3, Sigma_era = {}; end %检查输入参数

Sigma_ins = intersect(Sigma_ins, Ed_o, 'stable');% 在可观事件集的Sigma_ins；交集
Sigma_era = intersect(Sigma_era, Ed_o, 'stable');

% 扩展事件集，Sigma_ins = {'a', 'b'};Ed_plus = {'a_+', 'b_+'};
Ed_plus  = cellfun(@(s)[s,'_+'], Sigma_ins, 'UniformOutput', false);
Ed_minus = cellfun(@(s)[s,'_-'], Sigma_era, 'UniformOutput', false); % names included though some may not be used per-state
EdA = [Ed_o, Ed_plus, Ed_minus];% attack alphabet

no = numel(Ed_o);%|Ed_o|
n_plus = numel(Ed_plus);%|Ed_plus|=|Sigma_ins|
n_minus = numel(Ed_minus);

% build map original symbol -> 0-based index；Ed_o = {'a', 'b', 'c'}--->symIndex('a') = 0;symIndex('b') = 1;
symIndex = containers.Map();
for j = 1:no, symIndex(Ed_o{j}) = j-1; end

% build δ_obs map: for each state map (0-based symIdx) -> (0-based dst)
delta_obs = cell(nd,1);%nd是状态数；delta_obs{1} 对应状态 0 的转移；delta_obs{2} 对应状态 1 的转移；
for r = 1:size(Td,1) %遍历转移表 Td 的每一行
    s = double(Td(r,1)); a = double(Td(r,2)); t = double(Td(r,3)); % all 0-based
    ci = s + 1; %MATLAB 索引是从 1 开始的，而状态编号是 0-based
    if isempty(delta_obs{ci})
        delta_obs{ci} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta_obs{ci}(int32(a)) = int32(t); %往当前状态 ci 的映射表中添加一个转移：事件 a → 目标状态 t
end

TdA = [];
% For each state, add transitions that attacker actually has
for q = 0:(nd-1)
    ci = q + 1;
    % Σ_o: copy existing δ_obs
    if ~isempty(delta_obs{ci})
        keys = delta_obs{ci}.keys;
        for kk = 1:numel(keys)
            a0 = double(keys{kk}); dst = double(delta_obs{ci}(int32(a0)));
            TdA(end+1,:) = [q, a0, dst]; %#ok<AGROW>
        end
    end
    % Σ_+ for Sigma_ins: attacker can insert -> we model as self-loop (attacker estimate unchanged)
    for j = 1:n_plus
        sym_plus_idx = no + (j-1); % 0-based in EdA
        TdA(end+1,:) = [q, sym_plus_idx, q]; %#ok<AGROW>
    end
    % Σ_- for Sigma_era: attacker can erase only if underlying e defined at this state -> map to same dst as e
    for j = 1:n_minus
        e = Sigma_era{j};
        a0 = symIndex(e); % 0-based original index
        if ~isempty(delta_obs{ci}) && isKey(delta_obs{ci}, int32(a0))
            dst = double(delta_obs{ci}(int32(a0)));
            sym_minus_idx = no + n_plus + (j-1);
            TdA(end+1,:) = [q, sym_minus_idx, dst]; %#ok<AGROW>
        end
    end
end

% Do NOT complete with sink (semantics B keeps attacker potentially partial)
n_att = nd;
G_att = {n_att, EdA, TdA, xd0, Xdm};
end
