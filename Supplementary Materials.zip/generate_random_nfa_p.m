function Gn_list = generate_random_nfa_p(num_examples, n_range, m_range, p_obs, p_ins, p_era, savefile)
% 
% 用法：
%   Gn_list = generate_random_nfa_p(10, [15 20], [4 8], 0.5, 0.3, 0.3, 'Gn_full.mat');
%
% 输出：Gn_list{e} = {n, E_cell, T, X0, Xm, Sigma_o, Sigma_ins, Sigma_era}
%   n:            状态数
%   E_cell:       事件元胞数组 {'a','b',...}
%   T:            转移表 [src, a_idx, dst] (1-based)
%   X0:           初始状态集合（索引）
%   Xm:           标记/接受状态集合（此处默认空，可按需修改）
%   Sigma_o:      可观测事件子集（cellstr）
%   Sigma_ins:    可插入事件（Sigma_o 的子集）
%   Sigma_era:    可删除事件（Sigma_o 的子集）
%
% 特性：
% - 可复现：固定随机种子（可按需调整）
% - 稀疏控制：rho 控制平均密度；|T| 统一兜底 < n^2
% - 弱连通保证：可选骨干加边（忽略方向）
% - 全量索引合法化：状态∈[1..n]，事件∈[1..m]
% - 打包前严格体检：越界时明确指出问题行
%
% 额外保证：
% - 兜底确保 |\Sigma_{era} \cup \Sigma_{ins}| >= 1

    % ========= 内部默认，可按需微调 =========
    seed            = 42;        % 随机种子（可复现）
    rho             = 0.30;      % 转移密度：每 (src,a) 以概率 rho 产生转移
    max_targets     = 2;         % 每 (src,a) 的最多目标数（非确定性强度）
    force_weak_conn = true;      % 是否保证弱连通
    avoid_selfloop  = false;     % 是否避免自环
    cap_under_n2    = true;      % 是否强制 |T| < n^2
    X0_size         = 1;         % 初始状态个数
    Xm_size         = 0;         % 标记状态个数（默认 0）
    % ======================================

    % ===== 输入校验 =====
    if nargin < 7, savefile = ''; end
    if num_examples <= 0, Gn_list = {}; return; end
    if numel(n_range) ~= 2, error('n_range must be [n_min n_max].'); end
    if numel(m_range) ~= 2, error('m_range must be [m_min m_max].'); end
    if ~(0 <= p_obs && p_obs <= 1), error('p_obs must be in [0,1].'); end
    if ~(0 <= p_ins && p_ins <= 1), error('p_ins must be in [0,1].'); end
    if ~(0 <= p_era && p_era <= 1), error('p_era must be in [0,1].'); end

    rng(seed);  % 可复现
    Gn_list = cell(1, num_examples);

    for e = 1:num_examples
        % —— 随机规模 —— 
        n = randi([n_range(1) n_range(2)]);
        m = randi([m_range(1) m_range(2)]);

        % —— 事件集 —— 
        E_cell = arrayfun(@(i) char('a'+i-1), 1:m, 'UniformOutput', false);
        m = numel(E_cell);   % 以 E_cell 为准，避免不一致

        % —— 可观测 Σ_o ——（四舍五入避免 0）
        n_obs   = max(1, round(p_obs * m));
        idx_obs = sort(randperm(m, n_obs));
        Sigma_o = E_cell(idx_obs);

        % —— 插入/删除 ——（相对 Σ_o 的比例）
        n_ins = min(numel(Sigma_o), round(p_ins * numel(Sigma_o)));
        n_era = min(numel(Sigma_o), round(p_era * numel(Sigma_o)));
        if ~isempty(Sigma_o)
            Sigma_ins = Sigma_o(sort(randperm(numel(Sigma_o), max(0,n_ins))));
            Sigma_era = Sigma_o(sort(randperm(numel(Sigma_o), max(0,n_era))));
        else
            Sigma_ins = {};
            Sigma_era = {};
        end

        % % ===== 兜底确保 |\Sigma_{era} \cup \Sigma_{ins}| >= 1 =====
        % % 若两者皆空，则从 Sigma_o 中随机挑 1 个事件，等概率放入 ins 或 era
        % if isempty(Sigma_ins) && isempty(Sigma_era) && ~isempty(Sigma_o)
        %     pick = Sigma_o{randi(numel(Sigma_o))};
        %     if rand < 0.5
        %         Sigma_ins = {pick};
        %     else
        %         Sigma_era = {pick};
        %     end
        % end
        % % ===== 兜底逻辑结束 =====

        % —— 初始/标记状态 ——（与旧版兼容，给出合理缺省）
        X0 = sort(randperm(n, max(1, min(n, X0_size))));
        Xm = [];  % 若你下游需要可改成：sort(setdiff(randperm(n, Xm_size), X0))

        % —— 生成稀疏/非确定性转移：期望 |T| ≈ rho * n * m —— 
        T = zeros(0,3);
        for src = 1:n
            for a = 1:m
                if rand < rho
                    k = randi([1 max_targets]);           % 非确定性目标数
                    dst = randperm(n, k);
                    if avoid_selfloop
                        dst(dst==src) = [];
                        if isempty(dst), continue; end
                        k = numel(dst);
                    end
                    T = [T; repmat([src, a], k, 1), dst(:)]; %#ok<AGROW>
                end
            end
        end

        % —— 索引合法化 + 去重 —— 
        if ~isempty(T)
            T(:,2) = max(1, min(m, T(:,2)));      % 事件索引 ∈ [1..m]
            T(:,1) = max(1, min(n, T(:,1)));      % 源状态 ∈ [1..n]
            T(:,3) = max(1, min(n, T(:,3)));      % 目标状态 ∈ [1..n]
            T = unique(T, 'rows');
        end

        % —— 弱连通保证（忽略方向）——
        if force_weak_conn && ~is_weakly_connected_pure(n, T)
            backbone = [(1:n-1)', randi([1 m], n-1, 1), (2:n)'];
            last     = [n, randi([1 m]), 1];
            T = [T; backbone; last];
            T(:,2) = max(1, min(m, T(:,2)));
            T(:,1) = max(1, min(n, T(:,1)));
            T(:,3) = max(1, min(n, T(:,3)));
            T = unique(T, 'rows');
        end

        % —— 兜底：|T| < n^2 ——（避免下游观察器爆炸）
        if cap_under_n2 && size(T,1) >= n^2
            T = T(randperm(size(T,1), n^2-1), :);
        end

        % —— 打包前严格体检（越界时明确指出问题行）——
        validate_Gn_strict({n, E_cell, T, X0, Xm, Sigma_o, Sigma_ins, Sigma_era});

        % —— 统计 & 打印 —— 
        fprintf('[Sample %d] states=%d, transitions=%d, |Sigma_o|=%d, |Sigma_ins|=%d, |Sigma_era|=%d\n', ...
            e, n, size(T,1), numel(Sigma_o), numel(Sigma_ins), numel(Sigma_era));

        % —— 打包到 Gn ——（与旧版结构一致）
        Gn_list{e} = {n, E_cell, T, X0, Xm, Sigma_o, Sigma_ins, Sigma_era};
    end

    % —— 可选保存 ——（与旧版相同行为）
    if ~isempty(savefile)
        try
            Gn_full = Gn_list; %#ok<NASGU>
            save(savefile, 'Gn_full');
        catch ME
            warning('Save failed: %s', ME.message);
        end
    end
end

% ===== 工具：弱连通性（忽略方向；纯 MATLAB 队列）=====
function tf = is_weakly_connected_pure(n, T)
    if n <= 1, tf = true; return; end
    if isempty(T), tf = false; return; end
    adj = cell(n,1);
    for i=1:n, adj{i} = []; end
    for r = 1:size(T,1)
        u = T(r,1); v = T(r,3);
        if u==v, continue; end
        adj{u} = unique([adj{u}, v]);
        adj{v} = unique([adj{v}, u]);
    end
    vis = false(1,n);
    q = zeros(1,n); head = 1; tail = 0;
    start = 1; vis(start) = true; tail = 1; q(tail)=start;
    while head <= tail
        x = q(head); head = head + 1;
        for y = adj{x}
            if ~vis(y)
                vis(y) = true; tail = tail + 1; q(tail) = y;
            end
        end
    end
    tf = all(vis);
end

% ===== 工具：生成后严格体检，定位坏行 =====
function validate_Gn_strict(Gn)
    n = double(Gn{1});
    E = Gn{2};
    T = double(Gn{3});
    X0 = double(Gn{4});
    if ~isscalar(n) || n<=0, error('n 非法'); end
    if ~iscell(E), error('E_cell 应为 cellstr'); end
    m = numel(E);
    if isempty(T), warning('T 为空：生成了无边自动机'); end
    if size(T,2)~=3, error('T 必须是 N×3'); end
    s = T(:,1); a = T(:,2); d = T(:,3);
    bad_state = find(s<1 | s>n | d<1 | d>n, 1);
    if ~isempty(bad_state)
        r = T(bad_state,:);
        error('T 中状态越界（行 %d: [%d %d %d], n=%d）', bad_state, r(1), r(2), r(3), n);
    end
    bad_event = find(a<1 | a>m, 1);
    if ~isempty(bad_event)
        r = T(bad_event,:);
        error('T 中事件越界（行 %d: a=%d, m=%d；[%d %d %d]）', bad_event, r(2), m, r(1), r(2), r(3));
    end
    if isempty(X0) || any(X0<1 | X0>n)
        error('X0 非法或越界');
    end
end
