function exists = check_successful_attacker(G_obs, GSJ1, GSJ2, opr_card, obs_state_card, opts)
% CHECK_SUCCESSFUL_ATTACKER (hardened)
% Inputs:
%   G_obs: observer graph (cell {n, Ed, Td, init,...}) -- 用于划分“可检测/不可检测”环
%   GSJ1 : trimmed stealthy JO (PbMode A)  —— 用于 C1（不确定环 -> 全单点诱导环）
%   GSJ2 : trimmed stealthy JO (PbMode B)  —— 用于 C2（可检测环 -> 存在 |q_opr|>1 的诱导环）
%   opr_card: operator y-sets 基数表（与 GSJ jointMap 中第二分量对齐，0-based+1索引访问）
%   obs_state_card: 观测器状态基数（与 G_obs 的状态编号 0..n-1 对齐；下标+1访问）
%   opts.max_cycle_len, opts.verbose
%
% Output:
%   exists: struct with fields:
%       C1_all_true, C2_all_true, exists_attack, report (cellstr)

    % ---- defaults & guards ----
    if nargin < 6 || isempty(opts), opts = struct(); end
    if ~isfield(opts,'max_cycle_len'), opts.max_cycle_len = 30; end
    if ~isfield(opts,'verbose'), opts.verbose = false; end
    if nargin < 5, obs_state_card = []; end

    exists = struct('C1_all_true',false,'C2_all_true',false, ...
                    'exists_attack',false,'report',{{}});

    % ---- unpack observer ----
    n_obs = 0; Td_obs = zeros(0,3);
    if iscell(G_obs) && numel(G_obs)>=3 && ~isempty(G_obs{1})
        n_obs = double(G_obs{1});
        Td_obs = double(G_obs{3});
    else
        exists.report{end+1} = '[Error] G_obs malformed or empty.';
        return;
    end

    % ---- sanity for obs_state_card ----
    if isempty(obs_state_card) || numel(obs_state_card) ~= n_obs
        exists.report{end+1} = sprintf('[Warn] obs_state_card length=%d mismatches n_obs=%d; fallback to all-ones.', ...
                                       numel(obs_state_card), n_obs);
        obs_state_card = ones(1, n_obs);
    end

    % ---- build adj lists ----
    adj_obs = build_adj_list(n_obs, Td_obs);

    [n1,Td1,jm1] = unpack_gsj(GSJ1);
    [n2,Td2,jm2] = unpack_gsj(GSJ2);
    adj1 = build_adj_list(n1, Td1);
    adj2 = build_adj_list(n2, Td2);

    % ---- enumerate cycles in observer ----
    maxL = opts.max_cycle_len;
    cyc_obs = enumer_simple_cycles(adj_obs, maxL);

    % classify
    detectable_cycles   = {};
    undetectable_cycles = {};
    for i=1:numel(cyc_obs)
        cyc = cyc_obs{i};
        cards = obs_state_card(cyc+1);
        if all(cards==1), detectable_cycles{end+1}=cyc; %#ok<AGROW>
        else,             undetectable_cycles{end+1}=cyc; %#ok<AGROW>
        end
    end

    % if opts.verbose
    %     fprintf('[Observer] cycles=%d; detectable=%d; undetectable=%d\n', ...
    %             numel(cyc_obs), numel(detectable_cycles), numel(undetectable_cycles));
    % end
    exists.report{end+1} = sprintf('Detected %d obs-cycles; detectable=%d, undetectable=%d', ...
                                   numel(cyc_obs), numel(detectable_cycles), numel(undetectable_cycles));

    % ---- enumerate cycles in GSJ1/GSJ2 ----
    cyc1 = enumer_simple_cycles(adj1, maxL);
    cyc2 = enumer_simple_cycles(adj2, maxL);
    exists.report{end+1} = sprintf('GSJ1 cycles: %d, GSJ2 cycles: %d', numel(cyc1), numel(cyc2));

    % helpers
    proj_att_seq = @(cycle, jm) project_attacker_sequence(cycle, jm); 
    proj_opr_cards = @(cycle, jm) project_opr_cardinality_seq(cycle, jm, opr_card);

    % ---- C1: for all undetectable cycles in G_obs, GSJ1 has determinacy-inducing cycle ----
    C1_ok = true; C1_missing = {};
    if isempty(undetectable_cycles)
        % vacuously true; 明确记录
        exists.report{end+1} = '[Note] No undetectable cycles in observer -> C1 vacuously true.';
    else
        if isempty(jm1)
            exists.report{end+1} = '[Warn] GSJ1 jointMap missing -> cannot verify C1 (set false).';
            C1_ok = false;
        else
            for i=1:numel(undetectable_cycles)
                cl = undetectable_cycles{i};
                cl_seq = [cl(:).' cl(1)];   % close
                matched = false;
                for j=1:numel(cyc1)
                    att_seq = proj_att_seq(cyc1{j}, jm1);
                    if isequal(att_seq, cl_seq)
                        opr_cards = proj_opr_cards(cyc1{j}, jm1);
                        if all(opr_cards == 1)
                            matched = true; break;
                        end
                    end
                end
                if ~matched
                    C1_ok = false; C1_missing{end+1} = cl; %#ok<AGROW>
                end
            end
        end
    end

    % ---- C2: for all detectable cycles in G_obs, GSJ2 has ambiguity-inducing cycle ----
    C2_ok = true; C2_missing = {};
    if isempty(detectable_cycles)
        % 这里按严格安全：既然无“可检测环”，则 C2 不作数；将其置为 false 并注明
        C2_ok = false;
        exists.report{end+1} = '[Note] No detectable cycles in observer -> C2 set to false.';
    else
        if isempty(jm2)
            exists.report{end+1} = '[Warn] GSJ2 jointMap missing -> cannot verify C2 (set false).';
            C2_ok = false;
        else
            for i=1:numel(detectable_cycles)
                cl = detectable_cycles{i};
                cl_seq = [cl(:).' cl(1)];
                matched = false;
                for j=1:numel(cyc2)
                    att_seq = proj_att_seq(cyc2{j}, jm2);
                    if isequal(att_seq, cl_seq)
                        opr_cards = proj_opr_cards(cyc2{j}, jm2);
                        if any(opr_cards > 1)
                            matched = true; break;
                        end
                    end
                end
                if ~matched
                    C2_ok = false; C2_missing{end+1} = cl; %#ok<AGROW>
                end
            end
        end
    end

    % ---- finalize ----
    exists.C1_all_true = C1_ok;
    exists.C2_all_true = C2_ok;
    exists.exists_attack = (C1_ok || C2_ok);

    exists.report{end+1} = sprintf('C1 (determinacy for undetectable cycles) => %d', C1_ok);
    exists.report{end+1} = sprintf('C2 (ambiguity for detectable cycles) => %d', C2_ok);
    if ~C1_ok
        exists.report{end+1} = sprintf('Undetectable cycles w/o determinacy match: %d', numel(C1_missing));
    end
    if ~C2_ok
        exists.report{end+1} = sprintf('Detectable cycles w/o ambiguity match: %d', numel(C2_missing));
    end

    if opts.verbose
        fprintf('\n===== SUMMARY =====\n');
        for i = 1:numel(exists.report), fprintf('%s\n', exists.report{i}); end
        if exists.exists_attack
            fprintf('=> At least one of C1 or C2 holds -> a successful attacker exists\n');
        else
            fprintf('=> Neither C1 nor C2 holds -> no successful attacker\n');
        end
    end
end

% ================= helpers =================
function adj = build_adj_list(n, Td)
    adj = cell(n,1);
    for i=1:n, adj{i} = []; end
    for r = 1:size(Td,1)
        s = Td(r,1); t = Td(r,3);
        adj{s+1}(end+1) = t;
    end
end

function [n,Td,jm] = unpack_gsj(G)
    n=0; Td=zeros(0,3); jm=[];
    if isempty(G) || ~iscell(G) || numel(G)<3, return; end
    if ~isempty(G{1}), n = double(G{1}); end
    if ~isempty(G{3}), Td = double(G{3}); end
    if numel(G)>=6 && isstruct(G{6}) && isfield(G{6},'jointMap')
        jm = G{6}.jointMap;
    end
end

function cycles = enumer_simple_cycles(adj, maxlen)
    n = numel(adj); cycles = {};
    for start = 0:n-1
        dfs(start, start, start, [], false(1,n));
    end
    function dfs(startNode, prev, cur, path, used)
        path2 = [path, cur]; %#ok<AGROW>
        if numel(path2) > maxlen, return; end
        used2 = used; used2(cur+1) = true;
        neigh = adj{cur+1};
        for v = neigh
            v = double(v);
            if v == startNode && ~isempty(path2)
                cyc = path2; 
                mn = min(cyc);
                idx = find(cyc==mn,1);
                cyc_rot = [cyc(idx:end) cyc(1:idx-1)];
                if cyc_rot(1) == startNode
                    if ~exists_cycle(cycles, cyc)
                        cycles{end+1} = cyc; %#ok<AGROW>
                    end
                end
            elseif v > startNode && ~used2(v+1)
                dfs(startNode, cur, v, path2, used2);
            end
        end
    end
end

function tf = exists_cycle(cycles, cyc)
    tf=false;
    for k=1:numel(cycles)
        if isequal(cycles{k}, cyc), tf=true; return; end
    end
end

function att_seq = project_attacker_sequence(cycle, jointMap)
    tmp = arrayfun(@(x) jointMap(x+1,1), cycle); 
    d = tmp([true, diff(tmp)~=0]);
    att_seq = [d(:).' d(1)];
end

function opr_cards_seq = project_opr_cardinality_seq(cycle, jointMap, opr_card)
    tmp_opr = arrayfun(@(x) jointMap(x+1,2), cycle); 
    cards = zeros(1,numel(tmp_opr));
    for i=1:numel(tmp_opr)
        cards(i) = opr_card(tmp_opr(i)+1);
    end
    att_tmp = arrayfun(@(x) jointMap(x+1,1), cycle);
    keep = [true, diff(att_tmp)~=0];
    cards_dedup = cards(keep);
    opr_cards_seq = [cards_dedup(:).' cards_dedup(1)];
end
